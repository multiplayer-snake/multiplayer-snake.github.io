"use client"

import type React from "react"
import { createContext, useContext, useRef, useCallback } from "react"

interface AudioContextType {
  playSound: (soundType: string, intensity?: number) => void
  setMasterVolume: (volume: number) => void
}

const AudioContext = createContext<AudioContextType | null>(null)

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const audioContextRef = useRef<AudioContext | null>(null)
  const masterVolumeRef = useRef(0.3)

  const initAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
    }
    return audioContextRef.current
  }, [])

  const playSound = useCallback(
    (soundType: string, intensity = 1) => {
      try {
        const audioCtx = initAudioContext()
        const oscillator = audioCtx.createOscillator()
        const gainNode = audioCtx.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(audioCtx.destination)

        let frequency = 440
        let duration = 0.2

        switch (soundType) {
          case "correct":
            frequency = 523 + intensity * 100 // C5 + intensity
            duration = 0.3
            break
          case "incorrect":
            frequency = 220 - intensity * 20 // A3 - intensity
            duration = 0.5
            break
          case "bonus":
            frequency = 659 + intensity * 150 // E5 + intensity
            duration = 0.4
            break
          case "genius":
            frequency = 880 + intensity * 200 // A5 + intensity
            duration = 0.6
            break
          case "tick":
            frequency = 800
            duration = 0.1
            break
          case "achievement":
            frequency = 1047 // C6
            duration = 0.8
            break
        }

        oscillator.frequency.setValueAtTime(frequency, audioCtx.currentTime)
        gainNode.gain.setValueAtTime(0, audioCtx.currentTime)
        gainNode.gain.linearRampToValueAtTime(masterVolumeRef.current * intensity, audioCtx.currentTime + 0.01)
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration)

        oscillator.start(audioCtx.currentTime)
        oscillator.stop(audioCtx.currentTime + duration)
      } catch (error) {
        console.warn("Audio playback failed:", error)
      }
    },
    [initAudioContext],
  )

  const setMasterVolume = useCallback((volume: number) => {
    masterVolumeRef.current = Math.max(0, Math.min(1, volume))
  }, [])

  return <AudioContext.Provider value={{ playSound, setMasterVolume }}>{children}</AudioContext.Provider>
}

export function useAudio() {
  const context = useContext(AudioContext)
  if (!context) {
    throw new Error("useAudio must be used within AudioProvider")
  }
  return context
}
