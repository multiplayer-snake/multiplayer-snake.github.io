"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"

// Predetermined questions - easily configurable
const QUESTIONS = [
  {
    id: 1,
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correct: 2,
    category: "Geography",
    difficulty: 1,
    story: "The City of Light awaits your knowledge...",
  },
  {
    id: 2,
    question: "What is 15 × 8?",
    options: ["120", "110", "130", "125"],
    correct: 0,
    category: "Mathematics",
    difficulty: 1,
    story: "Numbers dance in perfect harmony...",
  },
  {
    id: 3,
    question: "Who wrote 'Romeo and Juliet'?",
    options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
    correct: 1,
    category: "Literature",
    difficulty: 2,
    story: "The greatest love story ever told...",
  },
  {
    id: 4,
    question: "What is the chemical symbol for gold?",
    options: ["Go", "Gd", "Au", "Ag"],
    correct: 2,
    category: "Science",
    difficulty: 2,
    story: "Ancient alchemists sought this precious element...",
  },
  {
    id: 5,
    question: "In which year did World War II end?",
    options: ["1944", "1945", "1946", "1943"],
    correct: 1,
    category: "History",
    difficulty: 2,
    story: "A pivotal moment that changed the world...",
  },
  {
    id: 6,
    question: "What is the square root of 144?",
    options: ["11", "12", "13", "14"],
    correct: 1,
    category: "Mathematics",
    difficulty: 2,
    story: "Perfect squares hold mathematical beauty...",
  },
  {
    id: 7,
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correct: 1,
    category: "Science",
    difficulty: 1,
    story: "A distant world beckons exploration...",
  },
  {
    id: 8,
    question: "What is the largest ocean on Earth?",
    options: ["Atlantic", "Indian", "Arctic", "Pacific"],
    correct: 3,
    category: "Geography",
    difficulty: 1,
    story: "Vast waters cover our blue planet...",
  },
]

interface GameState {
  // Core Stats
  xp: number
  level: number
  streak: number
  masteryPoints: number
  totalAnswered: number
  correctAnswers: number

  // Current Session
  currentQuestion: any
  questionIndex: number
  timeLeft: number
  isAnswering: boolean
  lastAnswer: boolean | null

  // Flow State
  difficulty: number
  momentum: number
  geniusMode: boolean
  geniusModeTimer: number

  // Progression
  achievements: string[]
  unlockedCategories: string[]
  skillTree: Record<string, number>
  fracturedGems: string[]

  // Rewards
  bonusMultiplier: number
  artifactTimer: number
  currentArtifact: string | null

  // Meta
  sessionStartTime: number
  dailyStreak: number
  lastPlayDate: string

  // Course Selection
  selectedCourse: string | null
  selectedSubject: string | null
  subjectData: any | null

  // Enhanced Addiction Mechanics
  dopamineLevel: number
  socialPressure: number
  competitiveRank: number
  dailyChallengeCompleted: boolean
  streakMultiplier: number
  lastPlayTime: number
  playStreak: number
}

const initialState: GameState = {
  xp: 0,
  level: 1,
  streak: 0,
  masteryPoints: 0,
  totalAnswered: 0,
  correctAnswers: 0,

  currentQuestion: null,
  questionIndex: 0,
  timeLeft: 30,
  isAnswering: false,
  lastAnswer: null,

  difficulty: 1,
  momentum: 0,
  geniusMode: false,
  geniusModeTimer: 0,

  achievements: [],
  unlockedCategories: ["Geography", "Mathematics"],
  skillTree: {},
  fracturedGems: [],

  bonusMultiplier: 1,
  artifactTimer: 0,
  currentArtifact: null,

  sessionStartTime: Date.now(),
  dailyStreak: 0,
  lastPlayDate: new Date().toDateString(),

  selectedCourse: null,
  selectedSubject: null,
  subjectData: null,

  dopamineLevel: 0,
  socialPressure: 0,
  competitiveRank: Math.floor(Math.random() * 1000) + 100,
  dailyChallengeCompleted: false,
  streakMultiplier: 1,
  lastPlayTime: Date.now(),
  playStreak: 0,
}

type GameAction =
  | { type: "SELECT_COURSE"; payload: { course: string; subject: string; subjectData: any } }
  | { type: "INCREASE_DOPAMINE"; payload: number }
  | { type: "UPDATE_SOCIAL_PRESSURE"; payload: number }
  | { type: "COMPLETE_DAILY_CHALLENGE" }
  | { type: "ANSWER_QUESTION"; payload: { answerIndex: number; timeBonus: number } }
  | { type: "NEXT_QUESTION" }
  | { type: "TICK_TIMER" }
  | { type: "ACTIVATE_GENIUS_MODE" }
  | { type: "UPDATE_MOMENTUM"; payload: number }
  | { type: "UNLOCK_ACHIEVEMENT"; payload: string }
  | { type: "REPAIR_GEM"; payload: string }
  | { type: "LOAD_SAVE"; payload: Partial<GameState> }

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "SELECT_COURSE": {
      const { course, subject, subjectData } = action.payload
      return {
        ...state,
        selectedCourse: course,
        selectedSubject: subject,
        subjectData: subjectData,
      }
    }

    case "INCREASE_DOPAMINE": {
      return {
        ...state,
        dopamineLevel: Math.min(state.dopamineLevel + action.payload, 100),
      }
    }

    case "UPDATE_SOCIAL_PRESSURE": {
      return {
        ...state,
        socialPressure: action.payload,
      }
    }

    case "COMPLETE_DAILY_CHALLENGE": {
      return {
        ...state,
        dailyChallengeCompleted: true,
        xp: state.xp + 500, // Bonus XP
      }
    }
    case "ANSWER_QUESTION": {
      const { answerIndex, timeBonus } = action.payload
      const isCorrect = answerIndex === state.currentQuestion.correct
      const baseXP = isCorrect ? 100 : 25
      const bonusXP = Math.floor(baseXP * state.bonusMultiplier * (1 + timeBonus))

      const newStreak = isCorrect ? state.streak + 1 : 0
      const newMomentum = isCorrect ? Math.min(state.momentum + 0.2, 2) : Math.max(state.momentum - 0.3, 0)

      // Variable ratio rewards
      const shouldGetBonus = Math.random() < 0.3 + newStreak * 0.05
      const newBonusMultiplier = shouldGetBonus ? 1.5 + Math.random() : 1

      // Genius mode activation
      const shouldActivateGenius = newStreak >= 5 && newStreak % 3 === 0

      return {
        ...state,
        xp: state.xp + bonusXP,
        streak: newStreak,
        momentum: newMomentum,
        totalAnswered: state.totalAnswered + 1,
        correctAnswers: state.correctAnswers + (isCorrect ? 1 : 0),
        lastAnswer: isCorrect,
        bonusMultiplier: newBonusMultiplier,
        geniusMode: shouldActivateGenius || state.geniusMode,
        geniusModeTimer: shouldActivateGenius ? 10 : state.geniusModeTimer,
        masteryPoints: state.masteryPoints + (isCorrect ? 10 : 0),
        fracturedGems: isCorrect ? state.fracturedGems : [...state.fracturedGems, state.currentQuestion.category],
      }
    }

    case "NEXT_QUESTION": {
      const availableQuestions = QUESTIONS.filter(
        (q) => state.unlockedCategories.includes(q.category) && Math.abs(q.difficulty - state.difficulty) <= 1,
      )

      const nextQuestion = availableQuestions[Math.floor(Math.random() * availableQuestions.length)]

      return {
        ...state,
        currentQuestion: nextQuestion,
        questionIndex: state.questionIndex + 1,
        timeLeft: Math.max(15, 30 - Math.floor(state.momentum * 5)),
        isAnswering: false,
        lastAnswer: null,
      }
    }

    case "TICK_TIMER": {
      const newTimeLeft = Math.max(0, state.timeLeft - 1)
      const newGeniusTimer = Math.max(0, state.geniusModeTimer - 1)

      return {
        ...state,
        timeLeft: newTimeLeft,
        geniusModeTimer: newGeniusTimer,
        geniusMode: newGeniusTimer > 0,
        artifactTimer: Math.max(0, state.artifactTimer - 1),
      }
    }

    case "UPDATE_MOMENTUM": {
      return {
        ...state,
        momentum: Math.max(0, Math.min(2, action.payload)),
        difficulty: Math.max(1, Math.min(3, 1 + action.payload)),
      }
    }

    case "UNLOCK_ACHIEVEMENT": {
      return {
        ...state,
        achievements: [...state.achievements, action.payload],
      }
    }

    case "LOAD_SAVE": {
      return {
        ...state,
        ...action.payload,
      }
    }

    default:
      return state
  }
}

const GameContext = createContext<{
  state: GameState
  dispatch: React.Dispatch<GameAction>
} | null>(null)

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState)

  // Load saved game
  useEffect(() => {
    const saved = localStorage.getItem("mindforge-save")
    if (saved) {
      try {
        const saveData = JSON.parse(saved)
        dispatch({ type: "LOAD_SAVE", payload: saveData })
      } catch (e) {
        console.error("Failed to load save:", e)
      }
    }

    // Initialize first question
    dispatch({ type: "NEXT_QUESTION" })
  }, [])

  // Auto-save
  useEffect(() => {
    const saveData = {
      xp: state.xp,
      level: state.level,
      streak: state.streak,
      masteryPoints: state.masteryPoints,
      totalAnswered: state.totalAnswered,
      correctAnswers: state.correctAnswers,
      achievements: state.achievements,
      unlockedCategories: state.unlockedCategories,
      skillTree: state.skillTree,
      dailyStreak: state.dailyStreak,
      lastPlayDate: state.lastPlayDate,
    }

    localStorage.setItem("mindforge-save", JSON.stringify(saveData))
  }, [state.xp, state.level, state.achievements])

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      dispatch({ type: "TICK_TIMER" })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return <GameContext.Provider value={{ state, dispatch }}>{children}</GameContext.Provider>
}

export function useGame() {
  const context = useContext(GameContext)
  if (!context) {
    throw new Error("useGame must be used within GameProvider")
  }
  return context
}
