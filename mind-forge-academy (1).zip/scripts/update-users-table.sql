-- Add first_name column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS first_name TEXT;

-- Update existing users to extract first name from full_name
UPDATE users 
SET first_name = SPLIT_PART(full_name, ' ', 1)
WHERE first_name IS NULL AND full_name IS NOT NULL;

-- Set default first_name for users without full_name
UPDATE users 
SET first_name = 'genius'
WHERE first_name IS NULL OR first_name = '';

-- Make first_name NOT NULL with default
ALTER TABLE users ALTER COLUMN first_name SET DEFAULT 'genius';
ALTER TABLE users ALTER COLUMN first_name SET NOT NULL;

-- Update the handle_new_user function to include first_name
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  user_full_name TEXT;
  user_first_name TEXT;
BEGIN
  -- Extract names from metadata
  user_full_name := COALESCE(
    new.raw_user_meta_data->>'full_name', 
    new.raw_user_meta_data->>'name', 
    'Anonymous User'
  );
  
  user_first_name := COALESCE(
    new.raw_user_meta_data->>'first_name',
    SPLIT_PART(user_full_name, ' ', 1),
    'genius'
  );

  INSERT INTO public.users (
    id, 
    email, 
    full_name, 
    first_name,
    avatar_url,
    ab_test_group,
    psychological_profile,
    learning_style,
    notification_preferences
  )
  VALUES (
    new.id,
    new.email,
    user_full_name,
    user_first_name,
    COALESCE(new.raw_user_meta_data->>'avatar_url', new.raw_user_meta_data->>'picture'),
    (ARRAY['control', 'gamified', 'social', 'achievement', 'curiosity'])[floor(random() * 5) + 1],
    jsonb_build_object(
      'motivationType', CASE WHEN random() > 0.5 THEN 'intrinsic' ELSE 'extrinsic' END,
      'competitiveLevel', floor(random() * 10) + 1,
      'socialInfluence', floor(random() * 10) + 1,
      'achievementOriented', random() > 0.3,
      'curiosityDriven', random() > 0.4,
      'lossAversion', floor(random() * 10) + 1,
      'instantGratification', floor(random() * 10) + 1,
      'streakMotivation', random() > 0.6,
      'socialProofSensitive', random() > 0.5,
      'challengeSeeker', random() > 0.4
    ),
    (ARRAY['visual', 'auditory', 'kinesthetic'])[floor(random() * 3) + 1],
    jsonb_build_object(
      'dailyReminders', true,
      'streakWarnings', true,
      'socialUpdates', true,
      'achievements', true,
      'challenges', true
    )
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
