-- Create question cache table for storing Groq-generated questions
CREATE TABLE IF NOT EXISTS public.question_cache (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    question_data JSONB NOT NULL,
    generation_metadata JSONB DEFAULT '{}',
    cache_key TEXT UNIQUE NOT NULL,
    usage_count INTEGER DEFAULT 0,
    performance_metrics JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_used TIMESTAMPTZ DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

-- Create user question history table
CREATE TABLE IF NOT EXISTS public.user_question_history (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    question_cache_id UUID REFERENCES public.question_cache(id) ON DELETE CASCADE,
    answer_index INTEGER NOT NULL,
    is_correct BOOLEAN NOT NULL,
    response_time_seconds REAL NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    session_id UUID -- Optional: link to learning session
);

-- Create question analytics table for performance tracking
CREATE TABLE IF NOT EXISTS public.question_analytics (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    question_cache_id UUID REFERENCES public.question_cache(id) ON DELETE CASCADE,
    metric_name TEXT NOT NULL,
    metric_value REAL NOT NULL,
    calculation_date TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

-- Create question generation logs table
CREATE TABLE IF NOT EXISTS public.question_generation_logs (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    generation_request JSONB NOT NULL,
    generation_response JSONB,
    groq_model_used TEXT,
    generation_time_ms INTEGER,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on all new tables
ALTER TABLE public.question_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_question_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_generation_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for question_cache (public read, system write)
CREATE POLICY "Anyone can view question cache" ON public.question_cache
    FOR SELECT USING (is_active = true);

CREATE POLICY "System can manage question cache" ON public.question_cache
    FOR ALL USING (true);

-- Create policies for user_question_history
CREATE POLICY "Users can view own question history" ON public.user_question_history
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own question history" ON public.user_question_history
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Create policies for question_analytics (read-only for users)
CREATE POLICY "Anyone can view question analytics" ON public.question_analytics
    FOR SELECT USING (true);

-- Create policies for question_generation_logs
CREATE POLICY "Users can view own generation logs" ON public.question_generation_logs
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own generation logs" ON public.question_generation_logs
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_question_cache_subject_id ON public.question_cache(subject_id);
CREATE INDEX IF NOT EXISTS idx_question_cache_cache_key ON public.question_cache(cache_key);
CREATE INDEX IF NOT EXISTS idx_question_cache_created_at ON public.question_cache(created_at);
CREATE INDEX IF NOT EXISTS idx_question_cache_usage_count ON public.question_cache(usage_count);

CREATE INDEX IF NOT EXISTS idx_user_question_history_user_id ON public.user_question_history(user_id);
CREATE INDEX IF NOT EXISTS idx_user_question_history_question_cache_id ON public.user_question_history(question_cache_id);
CREATE INDEX IF NOT EXISTS idx_user_question_history_created_at ON public.user_question_history(created_at);
CREATE INDEX IF NOT EXISTS idx_user_question_history_is_correct ON public.user_question_history(is_correct);

CREATE INDEX IF NOT EXISTS idx_question_analytics_question_cache_id ON public.question_analytics(question_cache_id);
CREATE INDEX IF NOT EXISTS idx_question_analytics_metric_name ON public.question_analytics(metric_name);

CREATE INDEX IF NOT EXISTS idx_question_generation_logs_user_id ON public.question_generation_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_question_generation_logs_subject_id ON public.question_generation_logs(subject_id);
CREATE INDEX IF NOT EXISTS idx_question_generation_logs_created_at ON public.question_generation_logs(created_at);

-- Create GIN indexes for JSONB columns for efficient querying
CREATE INDEX IF NOT EXISTS idx_question_cache_question_data_gin ON public.question_cache USING GIN (question_data);
CREATE INDEX IF NOT EXISTS idx_question_cache_performance_metrics_gin ON public.question_cache USING GIN (performance_metrics);
CREATE INDEX IF NOT EXISTS idx_user_question_history_metadata_gin ON public.user_question_history USING GIN (metadata);

-- Create function to clean up old question cache entries
CREATE OR REPLACE FUNCTION public.cleanup_question_cache()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- Delete unused questions older than 30 days with low usage
    DELETE FROM public.question_cache
    WHERE created_at < NOW() - INTERVAL '30 days'
    AND usage_count < 5
    AND last_used < NOW() - INTERVAL '7 days';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Log the cleanup
    INSERT INTO public.question_generation_logs (
        user_id,
        subject_id,
        generation_request,
        generation_response,
        success,
        error_message
    ) VALUES (
        NULL,
        NULL,
        '{"action": "cleanup"}',
        jsonb_build_object('deleted_count', deleted_count),
        true,
        'Automated cleanup completed'
    );
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to calculate question difficulty accuracy
CREATE OR REPLACE FUNCTION public.calculate_question_difficulty_accuracy(question_cache_id UUID)
RETURNS REAL AS $$
DECLARE
    intended_difficulty REAL;
    actual_difficulty REAL;
    accuracy_rate REAL;
BEGIN
    -- Get intended difficulty from question data
    SELECT (question_data->>'difficulty')::REAL
    INTO intended_difficulty
    FROM public.question_cache
    WHERE id = question_cache_id;
    
    -- Calculate actual difficulty based on user performance
    SELECT AVG(CASE WHEN is_correct THEN 1.0 ELSE 0.0 END)
    INTO accuracy_rate
    FROM public.user_question_history
    WHERE question_cache_id = calculate_question_difficulty_accuracy.question_cache_id;
    
    -- Convert accuracy to difficulty scale (lower accuracy = higher difficulty)
    actual_difficulty := 10.0 * (1.0 - COALESCE(accuracy_rate, 0.5));
    
    -- Return accuracy of difficulty prediction (1.0 = perfect, 0.0 = completely wrong)
    RETURN 1.0 - ABS(intended_difficulty - actual_difficulty) / 10.0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get adaptive question recommendations
CREATE OR REPLACE FUNCTION public.get_adaptive_question_params(user_id UUID, subject_id UUID)
RETURNS JSONB AS $$
DECLARE
    user_profile RECORD;
    recent_performance RECORD;
    recommended_difficulty REAL;
    recommended_concepts TEXT[];
BEGIN
    -- Get user profile
    SELECT * INTO user_profile
    FROM public.users
    WHERE id = user_id;
    
    -- Calculate recent performance
    SELECT 
        AVG(CASE WHEN is_correct THEN 1.0 ELSE 0.0 END) as accuracy,
        AVG(response_time_seconds) as avg_response_time,
        COUNT(*) as total_questions
    INTO recent_performance
    FROM public.user_question_history uqh
    JOIN public.question_cache qc ON uqh.question_cache_id = qc.id
    WHERE uqh.user_id = get_adaptive_question_params.user_id
    AND qc.subject_id = get_adaptive_question_params.subject_id
    AND uqh.created_at > NOW() - INTERVAL '7 days';
    
    -- Calculate recommended difficulty
    recommended_difficulty := COALESCE(user_profile.preferred_difficulty, 5);
    
    IF recent_performance.accuracy > 0.8 THEN
        recommended_difficulty := LEAST(recommended_difficulty + 1, 10);
    ELSIF recent_performance.accuracy < 0.6 THEN
        recommended_difficulty := GREATEST(recommended_difficulty - 1, 1);
    END IF;
    
    -- Get recommended concepts based on weak areas
    SELECT ARRAY_AGG(DISTINCT concept)
    INTO recommended_concepts
    FROM (
        SELECT jsonb_array_elements_text(qc.question_data->'concept_tags') as concept
        FROM public.user_question_history uqh
        JOIN public.question_cache qc ON uqh.question_cache_id = qc.id
        WHERE uqh.user_id = get_adaptive_question_params.user_id
        AND qc.subject_id = get_adaptive_question_params.subject_id
        AND uqh.is_correct = false
        AND uqh.created_at > NOW() - INTERVAL '14 days'
        GROUP BY concept
        ORDER BY COUNT(*) DESC
        LIMIT 3
    ) weak_concepts;
    
    RETURN jsonb_build_object(
        'recommended_difficulty', recommended_difficulty,
        'recommended_concepts', COALESCE(recommended_concepts, ARRAY[]::TEXT[]),
        'recent_accuracy', COALESCE(recent_performance.accuracy, 0),
        'avg_response_time', COALESCE(recent_performance.avg_response_time, 30),
        'total_recent_questions', COALESCE(recent_performance.total_questions, 0)
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create materialized view for question performance analytics
CREATE MATERIALIZED VIEW IF NOT EXISTS public.question_performance_summary AS
SELECT 
    qc.id,
    qc.subject_id,
    qc.question_data->>'difficulty' as intended_difficulty,
    qc.usage_count,
    COUNT(uqh.id) as total_responses,
    AVG(CASE WHEN uqh.is_correct THEN 1.0 ELSE 0.0 END) as accuracy_rate,
    AVG(uqh.response_time_seconds) as avg_response_time,
    STDDEV(uqh.response_time_seconds) as response_time_stddev,
    public.calculate_question_difficulty_accuracy(qc.id) as difficulty_accuracy,
    qc.created_at,
    qc.last_used
FROM public.question_cache qc
LEFT JOIN public.user_question_history uqh ON qc.id = uqh.question_cache_id
WHERE qc.is_active = true
GROUP BY qc.id, qc.subject_id, qc.question_data, qc.usage_count, qc.created_at, qc.last_used;

-- Create index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_question_performance_summary_id ON public.question_performance_summary(id);
CREATE INDEX IF NOT EXISTS idx_question_performance_summary_subject_id ON public.question_performance_summary(subject_id);
CREATE INDEX IF NOT EXISTS idx_question_performance_summary_accuracy_rate ON public.question_performance_summary(accuracy_rate);

-- Create function to refresh the materialized view
CREATE OR REPLACE FUNCTION public.refresh_question_performance_summary()
RETURNS VOID AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY public.question_performance_summary;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert sample subjects if they don't exist
INSERT INTO public.subjects (course_id, name, description, icon, difficulty) 
SELECT 
    c.id,
    'Sample Mathematics',
    'Basic mathematical concepts and problem solving',
    '🔢',
    'beginner'
FROM public.courses c 
WHERE c.name = 'Mathematics Fundamentals'
AND NOT EXISTS (SELECT 1 FROM public.subjects WHERE name = 'Sample Mathematics')
LIMIT 1;
