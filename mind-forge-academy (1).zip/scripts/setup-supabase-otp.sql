-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Ensure RLS is enabled on auth.users (should be by default)
-- This is handled by Supabase automatically

-- Create or update users table with proper structure
CREATE TABLE IF NOT EXISTS public.users (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    first_name TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_active TIMESTAMPTZ DEFAULT NOW(),
    total_xp INTEGER DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    study_time_minutes INTEGER DEFAULT 0,
    preferred_difficulty INTEGER DEFAULT 5,
    learning_style TEXT DEFAULT 'visual',
    ab_test_group TEXT DEFAULT 'control',
    psychological_profile JSONB DEFAULT '{}',
    notification_preferences JSONB DEFAULT '{
        "dailyReminders": true,
        "streakWarnings": true,
        "socialUpdates": true,
        "achievements": true,
        "challenges": true
    }'
);

-- Enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
DROP POLICY IF EXISTS "Users can view own profile" ON public.users;
CREATE POLICY "Users can view own profile" ON public.users
    FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.users;
CREATE POLICY "Users can update own profile" ON public.users
    FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON public.users;
CREATE POLICY "Users can insert own profile" ON public.users
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Create function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.users (
        id,
        email,
        full_name,
        first_name,
        avatar_url
    )
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', 'Anonymous User'),
        COALESCE(
            NEW.raw_user_meta_data->>'first_name',
            SPLIT_PART(COALESCE(NEW.raw_user_meta_data->>'full_name', 'Anonymous'), ' ', 1)
        ),
        NEW.raw_user_meta_data->>'avatar_url'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create courses table
CREATE TABLE IF NOT EXISTS public.courses (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    difficulty_level INTEGER NOT NULL DEFAULT 1,
    total_questions INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create subjects table
CREATE TABLE IF NOT EXISTS public.subjects (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT '📚',
    difficulty TEXT NOT NULL DEFAULT 'beginner',
    total_questions INTEGER DEFAULT 0,
    mastery_threshold INTEGER DEFAULT 80,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create questions table
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    options TEXT[] NOT NULL,
    correct_answer INTEGER NOT NULL,
    explanation TEXT NOT NULL,
    difficulty INTEGER NOT NULL DEFAULT 5,
    concept_tags TEXT[] DEFAULT '{}',
    prerequisite_concepts TEXT[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    ai_generated BOOLEAN DEFAULT FALSE,
    base_version TEXT NOT NULL DEFAULT 'v1'
);

-- Create question_variants table for A/B testing
CREATE TABLE IF NOT EXISTS public.question_variants (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    base_question_id UUID REFERENCES public.questions(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    variant_text TEXT NOT NULL,
    variant_options TEXT[] NOT NULL,
    ab_test_group TEXT NOT NULL,
    psychological_triggers TEXT[] DEFAULT '{}',
    engagement_score REAL DEFAULT 0,
    success_rate REAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create user_progress table
CREATE TABLE IF NOT EXISTS public.user_progress (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    mastery_level REAL DEFAULT 0,
    questions_answered INTEGER DEFAULT 0,
    questions_correct INTEGER DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    last_studied TIMESTAMPTZ DEFAULT NOW(),
    time_spent_minutes INTEGER DEFAULT 0,
    difficulty_progression INTEGER[] DEFAULT '{}',
    concept_mastery JSONB DEFAULT '{}',
    learning_velocity REAL DEFAULT 0,
    retention_rate REAL DEFAULT 0,
    UNIQUE(user_id, subject_id)
);

-- Create learning_sessions table
CREATE TABLE IF NOT EXISTS public.learning_sessions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES public.subjects(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    ended_at TIMESTAMPTZ,
    questions_answered INTEGER DEFAULT 0,
    questions_correct INTEGER DEFAULT 0,
    xp_gained INTEGER DEFAULT 0,
    engagement_metrics JSONB DEFAULT '{}',
    psychological_state JSONB DEFAULT '{}',
    flow_state_duration INTEGER DEFAULT 0,
    dopamine_triggers_used TEXT[] DEFAULT '{}'
);

-- Create ab_test_results table
CREATE TABLE IF NOT EXISTS public.ab_test_results (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    test_name TEXT NOT NULL,
    variant TEXT NOT NULL,
    metric_name TEXT NOT NULL,
    metric_value REAL NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    context JSONB DEFAULT '{}'
);

-- Enable RLS on all tables
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.learning_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ab_test_results ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access on courses, subjects, questions
CREATE POLICY "Anyone can view courses" ON public.courses FOR SELECT USING (true);
CREATE POLICY "Anyone can view subjects" ON public.subjects FOR SELECT USING (true);
CREATE POLICY "Anyone can view questions" ON public.questions FOR SELECT USING (true);

-- Create policies for user-specific data
CREATE POLICY "Users can view own variants" ON public.question_variants FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own variants" ON public.question_variants FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own progress" ON public.user_progress FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own progress" ON public.user_progress FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own progress" ON public.user_progress FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own sessions" ON public.learning_sessions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own sessions" ON public.learning_sessions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own sessions" ON public.learning_sessions FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own test results" ON public.ab_test_results FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own test results" ON public.ab_test_results FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Insert sample data
INSERT INTO public.courses (name, description, category, difficulty_level) VALUES
('Mathematics Fundamentals', 'Core mathematical concepts and problem-solving', 'Mathematics', 1),
('Science Basics', 'Introduction to scientific principles', 'Science', 1),
('Language Arts', 'Reading, writing, and communication skills', 'Language', 1)
ON CONFLICT DO NOTHING;

-- Get course IDs for subjects
DO $$
DECLARE
    math_course_id UUID;
    science_course_id UUID;
    language_course_id UUID;
BEGIN
    SELECT id INTO math_course_id FROM public.courses WHERE name = 'Mathematics Fundamentals';
    SELECT id INTO science_course_id FROM public.courses WHERE name = 'Science Basics';
    SELECT id INTO language_course_id FROM public.courses WHERE name = 'Language Arts';

    -- Insert subjects
    INSERT INTO public.subjects (course_id, name, description, icon, difficulty) VALUES
    (math_course_id, 'Algebra', 'Linear equations and algebraic thinking', '🔢', 'intermediate'),
    (math_course_id, 'Geometry', 'Shapes, angles, and spatial reasoning', '📐', 'beginner'),
    (science_course_id, 'Physics', 'Motion, energy, and forces', '⚛️', 'intermediate'),
    (science_course_id, 'Chemistry', 'Elements, compounds, and reactions', '🧪', 'intermediate'),
    (language_course_id, 'Grammar', 'Sentence structure and language rules', '📝', 'beginner'),
    (language_course_id, 'Literature', 'Reading comprehension and analysis', '📚', 'intermediate')
    ON CONFLICT DO NOTHING;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);
CREATE INDEX IF NOT EXISTS idx_user_progress_user_id ON public.user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_learning_sessions_user_id ON public.learning_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_question_variants_user_id ON public.question_variants(user_id);
CREATE INDEX IF NOT EXISTS idx_ab_test_results_user_id ON public.ab_test_results(user_id);
