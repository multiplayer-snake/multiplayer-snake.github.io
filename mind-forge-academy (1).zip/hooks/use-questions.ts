"use client"

import { useState, useEffect, useCallback } from "react"
import { questionManager, type QuestionSearchParams } from "@/lib/question-manager"
import type { GeneratedQuestion } from "@/lib/groq-client"

export interface UseQuestionsOptions {
  adaptiveMode?: boolean
  difficulty?: number
  conceptTags?: string[]
  autoLoad?: boolean
}

export function useQuestions(subjectId: string, userId: string, options: UseQuestionsOptions = {}) {
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([])
  const [currentQuestion, setCurrentQuestion] = useState<GeneratedQuestion | null>(null)
  const [questionIndex, setQuestionIndex] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [questionCacheId, setQuestionCacheId] = useState<string | null>(null)

  const { adaptiveMode = false, difficulty, conceptTags, autoLoad = true } = options

  // Load questions on mount
  useEffect(() => {
    if (autoLoad && subjectId && userId) {
      if (adaptiveMode) {
        getAdaptiveQuestion()
      } else {
        loadQuestions()
      }
    }
  }, [subjectId, userId, autoLoad, adaptiveMode])

  // Update current question when questions or index changes
  useEffect(() => {
    if (questions.length > 0 && questionIndex < questions.length) {
      setCurrentQuestion(questions[questionIndex])
    } else {
      setCurrentQuestion(null)
    }
  }, [questions, questionIndex])

  const loadQuestions = useCallback(
    async (count = 10, loadOptions: { adaptToUser?: boolean; forceGenerate?: boolean } = {}) => {
      if (!subjectId || !userId) return

      setLoading(true)
      setError(null)

      try {
        const generatedQuestions = await questionManager.getQuestionsForSubject(subjectId, userId, count, {
          difficulty,
          adaptToUser: loadOptions.adaptToUser ?? true,
          forceGenerate: loadOptions.forceGenerate ?? false,
        })

        setQuestions(generatedQuestions)
        setQuestionIndex(0)

        // Get the cache ID for the first question
        if (generatedQuestions.length > 0) {
          const cachedQuestions = await questionManager.searchQuestions({
            subject_id: subjectId,
            limit: 1,
          })
          if (cachedQuestions.length > 0) {
            setQuestionCacheId(cachedQuestions[0].id)
          }
        }
      } catch (err: any) {
        console.error("Error loading questions:", err)
        setError(err.message || "Failed to load questions")
      } finally {
        setLoading(false)
      }
    },
    [subjectId, userId, difficulty],
  )

  const getAdaptiveQuestion = useCallback(async () => {
    if (!subjectId || !userId) return

    setLoading(true)
    setError(null)

    try {
      const adaptiveQuestion = await questionManager.getAdaptiveQuestion(subjectId, userId)
      setQuestions([adaptiveQuestion])
      setCurrentQuestion(adaptiveQuestion)
      setQuestionIndex(0)

      // Get the cache ID for the adaptive question
      const cachedQuestions = await questionManager.searchQuestions({
        subject_id: subjectId,
        limit: 1,
      })
      if (cachedQuestions.length > 0) {
        setQuestionCacheId(cachedQuestions[0].id)
      }
    } catch (err: any) {
      console.error("Error getting adaptive question:", err)
      setError(err.message || "Failed to get adaptive question")
    } finally {
      setLoading(false)
    }
  }, [subjectId, userId])

  const nextQuestion = useCallback(() => {
    if (adaptiveMode) {
      // In adaptive mode, get a new question
      getAdaptiveQuestion()
    } else {
      // In normal mode, move to next question in the array
      if (questionIndex < questions.length - 1) {
        setQuestionIndex((prev) => prev + 1)
      }
    }
  }, [adaptiveMode, questionIndex, questions.length, getAdaptiveQuestion])

  const previousQuestion = useCallback(() => {
    if (!adaptiveMode && questionIndex > 0) {
      setQuestionIndex((prev) => prev - 1)
    }
  }, [adaptiveMode, questionIndex])

  const recordAnswer = useCallback(
    async (answerIndex: number, isCorrect: boolean, responseTime: number, metadata: any = {}) => {
      if (!userId || !questionCacheId) {
        console.warn("Cannot record answer: missing userId or questionCacheId")
        return
      }

      try {
        await questionManager.recordAnswer(userId, questionCacheId, answerIndex, isCorrect, responseTime, metadata)
      } catch (err: any) {
        console.error("Error recording answer:", err)
        // Don't throw here to avoid disrupting the user experience
      }
    },
    [userId, questionCacheId],
  )

  const searchQuestions = useCallback(
    async (searchParams: Partial<QuestionSearchParams>) => {
      setLoading(true)
      setError(null)

      try {
        const results = await questionManager.searchQuestions({
          subject_id: subjectId,
          user_id: userId,
          ...searchParams,
        })

        const questionData = results.map((result) => result.question_data)
        setQuestions(questionData)
        setQuestionIndex(0)

        return results
      } catch (err: any) {
        console.error("Error searching questions:", err)
        setError(err.message || "Failed to search questions")
        return []
      } finally {
        setLoading(false)
      }
    },
    [subjectId, userId],
  )

  const generateVariants = useCallback(
    async (baseQuestionId: string, variantTypes: Array<"easier" | "harder" | "different_style" | "remedial">) => {
      if (!userId) return []

      setLoading(true)
      setError(null)

      try {
        const variants = await questionManager.generateQuestionVariants(baseQuestionId, userId, variantTypes)
        return variants
      } catch (err: any) {
        console.error("Error generating variants:", err)
        setError(err.message || "Failed to generate question variants")
        return []
      } finally {
        setLoading(false)
      }
    },
    [userId],
  )

  const analyzeQuestion = useCallback(async (questionId: string) => {
    try {
      const analysis = await questionManager.analyzeQuestionEffectiveness(questionId)
      return analysis
    } catch (err: any) {
      console.error("Error analyzing question:", err)
      return null
    }
  }, [])

  // Computed properties
  const totalQuestions = questions.length
  const progress = totalQuestions > 0 ? ((questionIndex + 1) / totalQuestions) * 100 : 0
  const hasNext = adaptiveMode || questionIndex < questions.length - 1
  const hasPrevious = !adaptiveMode && questionIndex > 0
  const isLastQuestion = !adaptiveMode && questionIndex === questions.length - 1

  return {
    // State
    questions,
    currentQuestion,
    questionIndex,
    totalQuestions,
    loading,
    error,
    questionCacheId,

    // Computed
    progress,
    hasNext,
    hasPrevious,
    isLastQuestion,

    // Actions
    loadQuestions,
    getAdaptiveQuestion,
    nextQuestion,
    previousQuestion,
    recordAnswer,
    searchQuestions,
    generateVariants,
    analyzeQuestion,

    // Utilities
    setQuestionIndex,
    setError,
  }
}
