import { supabase } from "./supabase"
import {
  generateQuestionBatch,
  generateAdaptiveQuestion,
  analyzeQuestionPerformance,
  generateQuestionVariant,
  type QuestionGenerationRequest,
  type GeneratedQuestion,
  type QuestionBatch,
} from "./groq-client"

export interface QuestionCacheEntry {
  id: string
  subject_id: string
  question_data: GeneratedQuestion
  generation_metadata: any
  usage_count: number
  performance_metrics: any
  created_at: string
  last_used: string
  cache_key: string
}

export interface QuestionSearchParams {
  subject_id?: string
  difficulty_range?: [number, number]
  concept_tags?: string[]
  bloom_levels?: string[]
  exclude_used?: boolean
  user_id?: string
  limit?: number
}

export class QuestionManager {
  private static instance: QuestionManager
  private cache: Map<string, QuestionCacheEntry> = new Map()
  private generationQueue: Map<string, Promise<QuestionBatch>> = new Map()

  static getInstance(): QuestionManager {
    if (!QuestionManager.instance) {
      QuestionManager.instance = new QuestionManager()
    }
    return QuestionManager.instance
  }

  /**
   * Get questions for a subject with intelligent caching and generation
   */
  async getQuestionsForSubject(
    subjectId: string,
    userId: string,
    count = 10,
    options: {
      difficulty?: number
      adaptToUser?: boolean
      forceGenerate?: boolean
    } = {},
  ): Promise<GeneratedQuestion[]> {
    try {
      const cacheKey = `${subjectId}_${userId}_${count}_${options.difficulty || "auto"}`

      // Check if we have enough cached questions
      if (!options.forceGenerate) {
        const cachedQuestions = await this.getCachedQuestions({
          subject_id: subjectId,
          exclude_used: true,
          user_id: userId,
          limit: count,
        })

        if (cachedQuestions.length >= count) {
          console.log(`Using ${cachedQuestions.length} cached questions for subject ${subjectId}`)
          return cachedQuestions.map((q) => q.question_data)
        }
      }

      // Generate new questions if cache is insufficient
      console.log(`Generating new questions for subject ${subjectId}`)
      return await this.generateAndCacheQuestions(subjectId, userId, count, options)
    } catch (error) {
      console.error("Error getting questions for subject:", error)
      throw error
    }
  }

  /**
   * Generate adaptive question based on user performance
   */
  async getAdaptiveQuestion(subjectId: string, userId: string): Promise<GeneratedQuestion> {
    try {
      // Get user profile and session context
      const [userProfile, sessionContext] = await Promise.all([
        this.getUserProfile(userId),
        this.getSessionContext(userId, subjectId),
      ])

      // Generate adaptive question using Groq
      const question = await generateAdaptiveQuestion(userProfile, sessionContext, subjectId)

      // Cache the generated question
      await this.cacheQuestion(subjectId, question, {
        generation_type: "adaptive",
        user_id: userId,
        session_context: sessionContext,
      })

      return question
    } catch (error) {
      console.error("Error generating adaptive question:", error)
      throw error
    }
  }

  /**
   * Search questions with advanced filtering
   */
  async searchQuestions(params: QuestionSearchParams): Promise<QuestionCacheEntry[]> {
    try {
      let query = supabase.from("question_cache").select("*")

      if (params.subject_id) {
        query = query.eq("subject_id", params.subject_id)
      }

      if (params.difficulty_range) {
        query = query
          .gte("question_data->difficulty", params.difficulty_range[0])
          .lte("question_data->difficulty", params.difficulty_range[1])
      }

      if (params.concept_tags && params.concept_tags.length > 0) {
        query = query.overlaps("question_data->concept_tags", params.concept_tags)
      }

      if (params.bloom_levels && params.bloom_levels.length > 0) {
        query = query.in("question_data->bloom_taxonomy_level", params.bloom_levels)
      }

      if (params.exclude_used && params.user_id) {
        // Exclude questions the user has already answered
        const { data: usedQuestions } = await supabase
          .from("user_question_history")
          .select("question_cache_id")
          .eq("user_id", params.user_id)

        if (usedQuestions && usedQuestions.length > 0) {
          const usedIds = usedQuestions.map((q) => q.question_cache_id)
          query = query.not("id", "in", `(${usedIds.join(",")})`)
        }
      }

      if (params.limit) {
        query = query.limit(params.limit)
      }

      query = query.order("created_at", { ascending: false })

      const { data, error } = await query

      if (error) {
        throw error
      }

      return data || []
    } catch (error) {
      console.error("Error searching questions:", error)
      return []
    }
  }

  /**
   * Record user's answer and update performance metrics
   */
  async recordAnswer(
    userId: string,
    questionCacheId: string,
    answerIndex: number,
    isCorrect: boolean,
    responseTime: number,
    metadata: any = {},
  ): Promise<void> {
    try {
      // Record the answer
      await supabase.from("user_question_history").insert({
        user_id: userId,
        question_cache_id: questionCacheId,
        answer_index: answerIndex,
        is_correct: isCorrect,
        response_time_seconds: responseTime,
        metadata: metadata,
      })

      // Update question performance metrics
      await this.updateQuestionMetrics(questionCacheId, isCorrect, responseTime)

      // Update usage count
      await supabase
        .from("question_cache")
        .update({
          usage_count: supabase.raw("usage_count + 1"),
          last_used: new Date().toISOString(),
        })
        .eq("id", questionCacheId)
    } catch (error) {
      console.error("Error recording answer:", error)
      throw error
    }
  }

  /**
   * Analyze question performance and get recommendations
   */
  async analyzeQuestionEffectiveness(questionCacheId: string): Promise<any> {
    try {
      // Get question data and user responses
      const [questionResult, responsesResult] = await Promise.all([
        supabase.from("question_cache").select("*").eq("id", questionCacheId).single(),
        supabase
          .from("user_question_history")
          .select("*")
          .eq("question_cache_id", questionCacheId)
          .order("created_at", { ascending: false })
          .limit(50),
      ])

      if (questionResult.error || !questionResult.data) {
        throw questionResult.error
      }

      const questionData = questionResult.data.question_data
      const responses = responsesResult.data || []

      // Use Groq to analyze performance
      const analysis = await analyzeQuestionPerformance(questionData, responses)

      // Update question metrics with analysis
      await supabase
        .from("question_cache")
        .update({
          performance_metrics: {
            ...questionResult.data.performance_metrics,
            ...analysis,
            last_analyzed: new Date().toISOString(),
          },
        })
        .eq("id", questionCacheId)

      return analysis
    } catch (error) {
      console.error("Error analyzing question effectiveness:", error)
      throw error
    }
  }

  /**
   * Generate question variants for different difficulty levels
   */
  async generateQuestionVariants(
    baseQuestionId: string,
    userId: string,
    variantTypes: Array<"easier" | "harder" | "different_style" | "remedial">,
  ): Promise<GeneratedQuestion[]> {
    try {
      // Get base question and user profile
      const [questionResult, userProfile] = await Promise.all([
        supabase.from("question_cache").select("*").eq("id", baseQuestionId).single(),
        this.getUserProfile(userId),
      ])

      if (questionResult.error || !questionResult.data) {
        throw questionResult.error
      }

      const baseQuestion = questionResult.data.question_data
      const variants: GeneratedQuestion[] = []

      // Generate each variant type
      for (const variantType of variantTypes) {
        try {
          const variant = await generateQuestionVariant(baseQuestion, userProfile, variantType)
          variants.push(variant)

          // Cache the variant
          await this.cacheQuestion(questionResult.data.subject_id, variant, {
            generation_type: "variant",
            variant_type: variantType,
            base_question_id: baseQuestionId,
            user_id: userId,
          })
        } catch (error) {
          console.error(`Error generating ${variantType} variant:`, error)
        }
      }

      return variants
    } catch (error) {
      console.error("Error generating question variants:", error)
      throw error
    }
  }

  /**
   * Private helper methods
   */
  private async generateAndCacheQuestions(
    subjectId: string,
    userId: string,
    count: number,
    options: any,
  ): Promise<GeneratedQuestion[]> {
    const cacheKey = `gen_${subjectId}_${userId}_${count}`

    // Check if generation is already in progress
    if (this.generationQueue.has(cacheKey)) {
      const batch = await this.generationQueue.get(cacheKey)!
      return batch.questions
    }

    // Start generation
    const generationPromise = this.performGeneration(subjectId, userId, count, options)
    this.generationQueue.set(cacheKey, generationPromise)

    try {
      const batch = await generationPromise

      // Cache all generated questions
      await Promise.all(
        batch.questions.map((question) =>
          this.cacheQuestion(subjectId, question, {
            generation_type: "batch",
            batch_metadata: batch.metadata,
            user_id: userId,
          }),
        ),
      )

      return batch.questions
    } finally {
      this.generationQueue.delete(cacheKey)
    }
  }

  private async performGeneration(
    subjectId: string,
    userId: string,
    count: number,
    options: any,
  ): Promise<QuestionBatch> {
    // Get subject and user information
    const [subjectResult, userProfile] = await Promise.all([
      supabase.from("subjects").select("*, courses(*)").eq("id", subjectId).single(),
      this.getUserProfile(userId),
    ])

    if (subjectResult.error || !subjectResult.data) {
      throw new Error("Subject not found")
    }

    const subject = subjectResult.data
    const difficulty = options.difficulty || userProfile?.preferred_difficulty || 5

    // Get user's previous questions to avoid duplicates
    const { data: previousQuestions } = await supabase
      .from("user_question_history")
      .select("question_cache(question_data)")
      .eq("user_id", userId)
      .limit(50)

    const previousTexts = previousQuestions?.map((pq) => pq.question_cache?.question_data?.question_text) || []

    // Prepare generation request
    const request: QuestionGenerationRequest = {
      subject: subject.name,
      difficulty: difficulty,
      conceptTags: [subject.name.toLowerCase(), subject.difficulty],
      count: count,
      userLevel: userProfile?.preferred_difficulty,
      learningStyle: userProfile?.learning_style,
      previousQuestions: previousTexts,
      userWeaknesses: userProfile?.psychological_profile?.weaknesses || [],
    }

    // Generate questions using Groq
    return await generateQuestionBatch(request)
  }

  private async cacheQuestion(subjectId: string, question: GeneratedQuestion, metadata: any): Promise<string> {
    const cacheKey = this.generateCacheKey(subjectId, question)

    const { data, error } = await supabase
      .from("question_cache")
      .insert({
        subject_id: subjectId,
        question_data: question,
        generation_metadata: metadata,
        cache_key: cacheKey,
        usage_count: 0,
        performance_metrics: {},
      })
      .select("id")
      .single()

    if (error) {
      console.error("Error caching question:", error)
      throw error
    }

    return data.id
  }

  private generateCacheKey(subjectId: string, question: GeneratedQuestion): string {
    const content = `${subjectId}_${question.question_text}_${question.difficulty}`
    return Buffer.from(content).toString("base64").slice(0, 50)
  }

  private async getCachedQuestions(params: QuestionSearchParams): Promise<QuestionCacheEntry[]> {
    return await this.searchQuestions(params)
  }

  private async getUserProfile(userId: string): Promise<any> {
    const { data, error } = await supabase.from("users").select("*").eq("id", userId).single()

    if (error) {
      console.error("Error fetching user profile:", error)
      return null
    }

    return data
  }

  private async getSessionContext(userId: string, subjectId: string): Promise<any> {
    // Get recent session data
    const { data: recentSessions } = await supabase
      .from("learning_sessions")
      .select("*")
      .eq("user_id", userId)
      .eq("subject_id", subjectId)
      .order("started_at", { ascending: false })
      .limit(5)

    // Get recent answers
    const { data: recentAnswers } = await supabase
      .from("user_question_history")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(10)

    const correctAnswers = recentAnswers?.filter((a) => a.is_correct).length || 0
    const totalAnswers = recentAnswers?.length || 1

    return {
      recent_accuracy: (correctAnswers / totalAnswers) * 100,
      current_streak: this.calculateCurrentStreak(recentAnswers || []),
      time_spent_minutes: recentSessions?.reduce((sum, s) => sum + (s.time_spent_minutes || 0), 0) || 0,
      difficulty_trend: this.analyzeDifficultyTrend(recentAnswers || []),
      recent_topics: recentSessions?.map((s) => s.subject_id).slice(0, 3) || [],
    }
  }

  private calculateCurrentStreak(answers: any[]): number {
    let streak = 0
    for (const answer of answers) {
      if (answer.is_correct) {
        streak++
      } else {
        break
      }
    }
    return streak
  }

  private analyzeDifficultyTrend(answers: any[]): string {
    if (answers.length < 3) return "stable"

    const recent = answers.slice(0, 3)
    const accuracy = recent.filter((a) => a.is_correct).length / recent.length

    if (accuracy > 0.8) return "increasing"
    if (accuracy < 0.4) return "decreasing"
    return "stable"
  }

  private async updateQuestionMetrics(
    questionCacheId: string,
    isCorrect: boolean,
    responseTime: number,
  ): Promise<void> {
    try {
      const { data: question } = await supabase
        .from("question_cache")
        .select("performance_metrics, usage_count")
        .eq("id", questionCacheId)
        .single()

      if (!question) return

      const metrics = question.performance_metrics || {}
      const totalAnswers = (metrics.total_answers || 0) + 1
      const correctAnswers = (metrics.correct_answers || 0) + (isCorrect ? 1 : 0)
      const totalTime = (metrics.total_response_time || 0) + responseTime

      const updatedMetrics = {
        ...metrics,
        total_answers: totalAnswers,
        correct_answers: correctAnswers,
        accuracy_rate: correctAnswers / totalAnswers,
        average_response_time: totalTime / totalAnswers,
        total_response_time: totalTime,
        last_updated: new Date().toISOString(),
      }

      await supabase.from("question_cache").update({ performance_metrics: updatedMetrics }).eq("id", questionCacheId)
    } catch (error) {
      console.error("Error updating question metrics:", error)
    }
  }
}

// Export singleton instance
export const questionManager = QuestionManager.getInstance()
