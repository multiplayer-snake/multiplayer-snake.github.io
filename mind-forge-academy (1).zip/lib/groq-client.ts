import Groq from "groq-sdk"

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY,
})

export interface QuestionGenerationRequest {
  subject: string
  difficulty: number
  conceptTags: string[]
  count: number
  userLevel?: number
  learningStyle?: string
  previousQuestions?: string[]
  userWeaknesses?: string[]
}

export interface GeneratedQuestion {
  question_text: string
  options: string[]
  correct_answer: number
  explanation: string
  difficulty: number
  concept_tags: string[]
  prerequisite_concepts: string[]
  estimated_time_seconds: number
  bloom_taxonomy_level: string
  cognitive_load: number
}

export interface QuestionBatch {
  questions: GeneratedQuestion[]
  metadata: {
    generation_strategy: string
    difficulty_distribution: number[]
    concept_coverage: string[]
    estimated_session_time: number
  }
}

export async function generateQuestionBatch(request: QuestionGenerationRequest): Promise<QuestionBatch> {
  const prompt = `Generate ${request.count} educational questions for ${request.subject} at difficulty level ${request.difficulty}/10.

CONTEXT:
- Subject: ${request.subject}
- Target Difficulty: ${request.difficulty}/10
- Concept Focus: ${request.conceptTags.join(", ")}
- User Level: ${request.userLevel || "Unknown"}
- Learning Style: ${request.learningStyle || "Mixed"}
- User Weaknesses: ${request.userWeaknesses?.join(", ") || "None identified"}

REQUIREMENTS:
1. Create questions that build upon each other progressively
2. Include a mix of knowledge levels (Remember, Understand, Apply, Analyze)
3. Ensure questions are engaging and contextually relevant
4. Avoid these previously asked questions: ${request.previousQuestions?.slice(0, 10).join("; ") || "None"}
5. Target cognitive load appropriate for the difficulty level
6. Include real-world applications where possible

QUESTION TYPES TO INCLUDE:
- Multiple choice (4 options)
- Scenario-based problems
- Conceptual understanding
- Application problems
- Analysis questions

Return ONLY valid JSON in this exact format:
{
  "questions": [
    {
      "question_text": "Clear, engaging question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correct_answer": 0,
      "explanation": "Detailed explanation of why this answer is correct and others are wrong",
      "difficulty": 5,
      "concept_tags": ["tag1", "tag2"],
      "prerequisite_concepts": ["concept1", "concept2"],
      "estimated_time_seconds": 45,
      "bloom_taxonomy_level": "Apply",
      "cognitive_load": 6
    }
  ],
  "metadata": {
    "generation_strategy": "adaptive_progressive",
    "difficulty_distribution": [2, 3, 4, 5, 6],
    "concept_coverage": ["concept1", "concept2"],
    "estimated_session_time": 300
  }
}`

  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an expert educational content creator and cognitive scientist. You specialize in creating adaptive, engaging questions that optimize learning outcomes. You understand Bloom's taxonomy, cognitive load theory, and personalized learning principles.

Your questions should:
- Be pedagogically sound and well-structured
- Match the specified difficulty precisely
- Build conceptual understanding progressively
- Include engaging, real-world contexts
- Provide comprehensive explanations
- Consider the learner's profile and weaknesses

Always return valid JSON only, no additional text.`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      model: "llama-3.1-70b-versatile",
      temperature: 0.7,
      max_tokens: 4000,
      top_p: 0.9,
    })

    const response = completion.choices[0]?.message?.content
    if (!response) {
      throw new Error("No response from Groq")
    }

    // Clean the response to ensure it's valid JSON
    const cleanedResponse = response.replace(/```json\n?|\n?```/g, "").trim()
    const parsed = JSON.parse(cleanedResponse)

    // Validate the response structure
    if (!parsed.questions || !Array.isArray(parsed.questions)) {
      throw new Error("Invalid response structure: missing questions array")
    }

    // Validate each question
    parsed.questions.forEach((q: any, index: number) => {
      if (!q.question_text || !Array.isArray(q.options) || q.options.length !== 4) {
        throw new Error(`Invalid question structure at index ${index}`)
      }
      if (typeof q.correct_answer !== "number" || q.correct_answer < 0 || q.correct_answer > 3) {
        throw new Error(`Invalid correct_answer at index ${index}`)
      }
    })

    return parsed as QuestionBatch
  } catch (error) {
    console.error("Failed to generate questions with Groq:", error)

    // Fallback to a basic question if Groq fails
    return {
      questions: [
        {
          question_text: `What is a fundamental concept in ${request.subject}?`,
          options: ["Option A", "Option B", "Option C", "Option D"],
          correct_answer: 0,
          explanation: "This is a basic question to ensure the system continues working.",
          difficulty: request.difficulty,
          concept_tags: request.conceptTags,
          prerequisite_concepts: [],
          estimated_time_seconds: 30,
          bloom_taxonomy_level: "Remember",
          cognitive_load: 3,
        },
      ],
      metadata: {
        generation_strategy: "fallback",
        difficulty_distribution: [request.difficulty],
        concept_coverage: request.conceptTags,
        estimated_session_time: 30,
      },
    }
  }
}

export async function generateAdaptiveQuestion(
  userProfile: any,
  sessionContext: any,
  subjectId: string,
): Promise<GeneratedQuestion> {
  const prompt = `Generate 1 adaptive question based on this user's learning profile and current session.

USER PROFILE:
- Learning Style: ${userProfile.learning_style}
- Current Level: ${userProfile.preferred_difficulty}/10
- Strengths: ${userProfile.psychological_profile?.strengths || "Unknown"}
- Weaknesses: ${userProfile.psychological_profile?.weaknesses || "Unknown"}
- Motivation Type: ${userProfile.psychological_profile?.motivationType || "Mixed"}

SESSION CONTEXT:
- Recent Performance: ${sessionContext.recent_accuracy || 0}% accuracy
- Current Streak: ${sessionContext.current_streak || 0}
- Time Spent: ${sessionContext.time_spent_minutes || 0} minutes
- Difficulty Trend: ${sessionContext.difficulty_trend || "stable"}
- Last 3 Topics: ${sessionContext.recent_topics?.join(", ") || "None"}

ADAPTIVE REQUIREMENTS:
1. If accuracy > 80%: Increase difficulty by 1-2 levels
2. If accuracy < 60%: Decrease difficulty by 1 level
3. If streak > 5: Add bonus complexity or real-world application
4. Match learning style (visual/auditory/kinesthetic)
5. Address identified weaknesses
6. Maintain engagement based on motivation type

Return ONLY valid JSON:
{
  "question_text": "Adaptive question text",
  "options": ["A", "B", "C", "D"],
  "correct_answer": 0,
  "explanation": "Detailed explanation",
  "difficulty": 5,
  "concept_tags": ["tag1"],
  "prerequisite_concepts": ["concept1"],
  "estimated_time_seconds": 45,
  "bloom_taxonomy_level": "Apply",
  "cognitive_load": 6
}`

  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an AI tutor that creates perfectly adapted questions for individual learners. You understand learning science, cognitive psychology, and adaptive education principles.

Your questions must:
- Precisely match the user's current ability level
- Address their specific learning style and preferences
- Build on their strengths while addressing weaknesses
- Maintain optimal challenge level (not too easy, not too hard)
- Keep them engaged based on their motivation profile

Always return valid JSON only.`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      model: "llama-3.1-70b-versatile",
      temperature: 0.8,
      max_tokens: 2000,
    })

    const response = completion.choices[0]?.message?.content
    if (!response) {
      throw new Error("No response from Groq")
    }

    const cleanedResponse = response.replace(/```json\n?|\n?```/g, "").trim()
    return JSON.parse(cleanedResponse) as GeneratedQuestion
  } catch (error) {
    console.error("Failed to generate adaptive question:", error)
    throw error
  }
}

export async function analyzeQuestionPerformance(
  questionData: any,
  userResponses: any[],
): Promise<{
  difficulty_accuracy: number
  engagement_score: number
  concept_mastery: Record<string, number>
  recommendations: string[]
}> {
  const prompt = `Analyze the performance data for this question and provide insights.

QUESTION DATA:
- Text: ${questionData.question_text}
- Difficulty: ${questionData.difficulty}/10
- Concepts: ${questionData.concept_tags?.join(", ")}
- Bloom Level: ${questionData.bloom_taxonomy_level}

USER RESPONSES (last 10):
${userResponses
  .slice(-10)
  .map((r, i) => `${i + 1}. Correct: ${r.is_correct}, Time: ${r.response_time}s, User Level: ${r.user_level}`)
  .join("\n")}

ANALYSIS REQUIREMENTS:
1. Calculate actual difficulty vs intended difficulty
2. Measure engagement (time spent, completion rate)
3. Assess concept mastery for each tag
4. Provide specific recommendations for improvement

Return ONLY valid JSON:
{
  "difficulty_accuracy": 0.85,
  "engagement_score": 0.92,
  "concept_mastery": {
    "concept1": 0.75,
    "concept2": 0.60
  },
  "recommendations": [
    "Increase difficulty by 1 level",
    "Add more visual elements",
    "Focus on concept2 reinforcement"
  ]
}`

  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are a learning analytics expert who analyzes educational content performance. You provide data-driven insights to improve question quality and learning outcomes.`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      model: "llama-3.1-70b-versatile",
      temperature: 0.3,
      max_tokens: 1500,
    })

    const response = completion.choices[0]?.message?.content
    if (!response) {
      throw new Error("No response from Groq")
    }

    const cleanedResponse = response.replace(/```json\n?|\n?```/g, "").trim()
    return JSON.parse(cleanedResponse)
  } catch (error) {
    console.error("Failed to analyze question performance:", error)
    return {
      difficulty_accuracy: 0.5,
      engagement_score: 0.5,
      concept_mastery: {},
      recommendations: ["Unable to analyze - using default metrics"],
    }
  }
}

export async function generateQuestionVariant(
  baseQuestion: any,
  userProfile: any,
  variantType: "easier" | "harder" | "different_style" | "remedial",
): Promise<GeneratedQuestion> {
  const prompt = `Create a ${variantType} variant of this question for the user profile.

BASE QUESTION:
- Text: ${baseQuestion.question_text}
- Options: ${baseQuestion.options?.join(" | ")}
- Correct: ${baseQuestion.correct_answer}
- Difficulty: ${baseQuestion.difficulty}/10
- Concepts: ${baseQuestion.concept_tags?.join(", ")}

USER PROFILE:
- Learning Style: ${userProfile.learning_style}
- Motivation: ${userProfile.psychological_profile?.motivationType}
- Weaknesses: ${userProfile.psychological_profile?.weaknesses || "None"}

VARIANT REQUIREMENTS:
- ${variantType === "easier" ? "Reduce difficulty by 2 levels, add more scaffolding" : ""}
- ${variantType === "harder" ? "Increase difficulty by 2 levels, add complexity" : ""}
- ${variantType === "different_style" ? "Same difficulty, different presentation style" : ""}
- ${variantType === "remedial" ? "Focus on prerequisite concepts, very supportive" : ""}

Return ONLY valid JSON with the same structure as before.`

  try {
    const completion = await groq.chat.completions.create({
      messages: [
        {
          role: "system",
          content: `You are an expert at creating question variants that maintain educational value while adapting to different needs and learning profiles.`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      model: "llama-3.1-70b-versatile",
      temperature: 0.7,
      max_tokens: 2000,
    })

    const response = completion.choices[0]?.message?.content
    if (!response) {
      throw new Error("No response from Groq")
    }

    const cleanedResponse = response.replace(/```json\n?|\n?```/g, "").trim()
    return JSON.parse(cleanedResponse) as GeneratedQuestion
  } catch (error) {
    console.error("Failed to generate question variant:", error)
    throw error
  }
}
