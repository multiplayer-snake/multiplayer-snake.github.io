import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Singleton pattern to prevent multiple instances
let supabaseInstance: ReturnType<typeof createClient> | null = null

const createSupabaseClient = () => {
  if (supabaseInstance) {
    return supabaseInstance
  }

  supabaseInstance = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
      flowType: "pkce",
      storage: typeof window !== "undefined" ? window.localStorage : undefined,
      storageKey: "mindforge-auth-token",
    },
  })

  return supabaseInstance
}

export const supabase = createSupabaseClient()

// Email verification helper
export const handleEmailVerification = async () => {
  const { data, error } = await supabase.auth.getSession()
  if (error) {
    console.error("Error getting session:", error)
    return false
  }
  return data.session?.user?.email_confirmed_at !== null
}

// Google sign in helper
export const signInWithGoogle = async () => {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo: `${window.location.origin}/auth/callback`,
      queryParams: {
        access_type: "offline",
        prompt: "consent",
      },
    },
  })

  if (error) {
    console.error("Google sign-in error:", error)
    throw error
  }

  return data
}

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          first_name: string
          avatar_url: string | null
          created_at: string
          last_active: string
          total_xp: number
          current_streak: number
          longest_streak: number
          study_time_minutes: number
          preferred_difficulty: number
          learning_style: string
          ab_test_group: string
          psychological_profile: any
          notification_preferences: any
        }
        Insert: {
          id: string
          email: string
          full_name: string
          first_name: string
          avatar_url?: string | null
          created_at?: string
          last_active?: string
          total_xp?: number
          current_streak?: number
          longest_streak?: number
          study_time_minutes?: number
          preferred_difficulty?: number
          learning_style?: string
          ab_test_group?: string
          psychological_profile?: any
          notification_preferences?: any
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          first_name?: string
          avatar_url?: string | null
          created_at?: string
          last_active?: string
          total_xp?: number
          current_streak?: number
          longest_streak?: number
          study_time_minutes?: number
          preferred_difficulty?: number
          learning_style?: string
          ab_test_group?: string
          psychological_profile?: any
          notification_preferences?: any
        }
      }
      courses: {
        Row: {
          id: string
          name: string
          description: string
          category: string
          difficulty_level: number
          total_questions: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          category: string
          difficulty_level: number
          total_questions?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          category?: string
          difficulty_level?: number
          total_questions?: number
          created_at?: string
          updated_at?: string
        }
      }
      subjects: {
        Row: {
          id: string
          course_id: string
          name: string
          description: string
          icon: string
          difficulty: string
          total_questions: number
          mastery_threshold: number
          created_at: string
        }
        Insert: {
          id?: string
          course_id: string
          name: string
          description: string
          icon: string
          difficulty: string
          total_questions?: number
          mastery_threshold?: number
          created_at?: string
        }
        Update: {
          id?: string
          course_id?: string
          name?: string
          description?: string
          icon?: string
          difficulty?: string
          total_questions?: number
          mastery_threshold?: number
          created_at?: string
        }
      }
      questions: {
        Row: {
          id: string
          subject_id: string
          question_text: string
          options: string[]
          correct_answer: number
          explanation: string
          difficulty: number
          concept_tags: string[]
          prerequisite_concepts: string[]
          created_at: string
          ai_generated: boolean
          base_version: string
        }
        Insert: {
          id?: string
          subject_id: string
          question_text: string
          options: string[]
          correct_answer: number
          explanation: string
          difficulty: number
          concept_tags: string[]
          prerequisite_concepts?: string[]
          created_at?: string
          ai_generated?: boolean
          base_version: string
        }
        Update: {
          id?: string
          subject_id?: string
          question_text?: string
          options?: string[]
          correct_answer?: number
          explanation?: string
          difficulty?: number
          concept_tags?: string[]
          prerequisite_concepts?: string[]
          created_at?: string
          ai_generated?: boolean
          base_version?: string
        }
      }
      question_variants: {
        Row: {
          id: string
          base_question_id: string
          user_id: string
          variant_text: string
          variant_options: string[]
          ab_test_group: string
          psychological_triggers: string[]
          engagement_score: number
          success_rate: number
          created_at: string
        }
        Insert: {
          id?: string
          base_question_id: string
          user_id: string
          variant_text: string
          variant_options: string[]
          ab_test_group: string
          psychological_triggers: string[]
          engagement_score?: number
          success_rate?: number
          created_at?: string
        }
        Update: {
          id?: string
          base_question_id?: string
          user_id?: string
          variant_text?: string
          variant_options?: string[]
          ab_test_group?: string
          psychological_triggers?: string[]
          engagement_score?: number
          success_rate?: number
          created_at?: string
        }
      }
      user_progress: {
        Row: {
          id: string
          user_id: string
          subject_id: string
          mastery_level: number
          questions_answered: number
          questions_correct: number
          current_streak: number
          last_studied: string
          time_spent_minutes: number
          difficulty_progression: number[]
          concept_mastery: any
          learning_velocity: number
          retention_rate: number
        }
        Insert: {
          id?: string
          user_id: string
          subject_id: string
          mastery_level?: number
          questions_answered?: number
          questions_correct?: number
          current_streak?: number
          last_studied?: string
          time_spent_minutes?: number
          difficulty_progression?: number[]
          concept_mastery?: any
          learning_velocity?: number
          retention_rate?: number
        }
        Update: {
          id?: string
          user_id?: string
          subject_id?: string
          mastery_level?: number
          questions_answered?: number
          questions_correct?: number
          current_streak?: number
          last_studied?: string
          time_spent_minutes?: number
          difficulty_progression?: number[]
          concept_mastery?: any
          learning_velocity?: number
          retention_rate?: number
        }
      }
      learning_sessions: {
        Row: {
          id: string
          user_id: string
          subject_id: string
          started_at: string
          ended_at: string | null
          questions_answered: number
          questions_correct: number
          xp_gained: number
          engagement_metrics: any
          psychological_state: any
          flow_state_duration: number
          dopamine_triggers_used: string[]
        }
        Insert: {
          id?: string
          user_id: string
          subject_id: string
          started_at?: string
          ended_at?: string | null
          questions_answered?: number
          questions_correct?: number
          xp_gained?: number
          engagement_metrics?: any
          psychological_state?: any
          flow_state_duration?: number
          dopamine_triggers_used?: string[]
        }
        Update: {
          id?: string
          user_id?: string
          subject_id?: string
          started_at?: string
          ended_at?: string | null
          questions_answered?: number
          questions_correct?: number
          xp_gained?: number
          engagement_metrics?: any
          psychological_state?: any
          flow_state_duration?: number
          dopamine_triggers_used?: string[]
        }
      }
      ab_test_results: {
        Row: {
          id: string
          user_id: string
          test_name: string
          variant: string
          metric_name: string
          metric_value: number
          timestamp: string
          context: any
        }
        Insert: {
          id?: string
          user_id: string
          test_name: string
          variant: string
          metric_name: string
          metric_value: number
          timestamp?: string
          context?: any
        }
        Update: {
          id?: string
          user_id?: string
          test_name?: string
          variant?: string
          metric_name?: string
          metric_value?: number
          timestamp?: string
          context?: any
        }
      }
    }
  }
}
