import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Terms & Conditions
            </h1>
            <p className="text-purple-200">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-invert max-w-none space-y-6 text-white">
            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">1. Acceptance of Terms</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  By accessing and using Mind Forge Academy ("the Service"), you accept and agree to be bound by the
                  terms and provision of this agreement. If you do not agree to abide by the above, please do not use
                  this service.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">2. Description of Service</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Mind Forge Academy is an AI-powered educational platform that provides personalized learning
                  experiences through:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Adaptive question generation and difficulty adjustment</li>
                  <li>Personalized learning paths and recommendations</li>
                  <li>Progress tracking and achievement systems</li>
                  <li>Interactive educational content across multiple subjects</li>
                  <li>AI-driven insights and learning analytics</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">3. User Accounts</h2>
              <div className="space-y-4 text-purple-100">
                <h3 className="text-lg font-semibold text-purple-200">Account Creation</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>You must be at least 13 years old to create an account</li>
                  <li>You must provide accurate and complete information</li>
                  <li>You are responsible for maintaining the security of your account</li>
                  <li>You must verify your email address to activate your account</li>
                </ul>

                <h3 className="text-lg font-semibold text-purple-200">Account Responsibilities</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Keep your login credentials secure and confidential</li>
                  <li>Notify us immediately of any unauthorized access</li>
                  <li>You are responsible for all activities under your account</li>
                  <li>Do not share your account with others</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">4. Acceptable Use</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  You agree to use Mind Forge Academy only for lawful purposes and in accordance with these Terms. You
                  agree NOT to:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Use the service for any illegal or unauthorized purpose</li>
                  <li>Attempt to gain unauthorized access to our systems</li>
                  <li>Interfere with or disrupt the service or servers</li>
                  <li>Upload malicious code or attempt to hack the platform</li>
                  <li>Harass, abuse, or harm other users</li>
                  <li>Share inappropriate or offensive content</li>
                  <li>Violate any applicable laws or regulations</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">5. AI and Personalization</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Mind Forge Academy uses artificial intelligence to enhance your learning experience. By using our
                  service, you acknowledge and agree that:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>AI systems analyze your learning patterns to provide personalized content</li>
                  <li>Question difficulty and content are automatically adjusted based on your performance</li>
                  <li>Learning recommendations are generated using machine learning algorithms</li>
                  <li>Your interaction data helps improve our AI systems for all users</li>
                  <li>AI-generated content may occasionally contain errors or inaccuracies</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">6. Intellectual Property</h2>
              <div className="space-y-4 text-purple-100">
                <h3 className="text-lg font-semibold text-purple-200">Our Content</h3>
                <p>
                  All content, features, and functionality of Mind Forge Academy, including but not limited to text,
                  graphics, logos, icons, images, audio clips, and software, are owned by us or our licensors and are
                  protected by copyright and other intellectual property laws.
                </p>

                <h3 className="text-lg font-semibold text-purple-200">Your Content</h3>
                <p>
                  You retain ownership of any content you submit to the platform. However, by submitting content, you
                  grant us a worldwide, non-exclusive, royalty-free license to use, reproduce, and distribute your
                  content in connection with the service.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">7. Privacy and Data Protection</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Your privacy is important to us. Our collection and use of personal information is governed by our
                  Privacy Policy, which is incorporated into these Terms by reference. By using our service, you consent
                  to the collection and use of your information as described in our Privacy Policy.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">8. Subscription and Payments</h2>
              <div className="space-y-4 text-purple-100">
                <p>Mind Forge Academy may offer both free and premium subscription tiers:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Free tier includes basic learning features with limitations</li>
                  <li>Premium subscriptions provide unlimited access to all features</li>
                  <li>Subscription fees are billed in advance on a recurring basis</li>
                  <li>You may cancel your subscription at any time</li>
                  <li>Refunds are provided according to our refund policy</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">9. Disclaimers</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Mind Forge Academy is provided "as is" without any warranties, expressed or implied. We do not
                  guarantee that:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>The service will be uninterrupted or error-free</li>
                  <li>All content is accurate or up-to-date</li>
                  <li>The service will meet your specific learning needs</li>
                  <li>AI-generated content is always correct or appropriate</li>
                  <li>Your learning progress will meet specific outcomes</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">10. Limitation of Liability</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  To the maximum extent permitted by law, Mind Forge Academy shall not be liable for any indirect,
                  incidental, special, consequential, or punitive damages, including but not limited to loss of profits,
                  data, or other intangible losses resulting from your use of the service.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">11. Termination</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  We may terminate or suspend your account and access to the service immediately, without prior notice,
                  for any reason, including but not limited to breach of these Terms. Upon termination, your right to
                  use the service will cease immediately.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">12. Changes to Terms</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  We reserve the right to modify these Terms at any time. We will notify users of any material changes
                  via email or through the platform. Your continued use of the service after such modifications
                  constitutes acceptance of the updated Terms.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">13. Governing Law</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in
                  which Mind Forge Academy operates, without regard to conflict of law principles.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">14. Contact Information</h2>
              <div className="space-y-4 text-purple-100">
                <p>If you have any questions about these Terms & Conditions, please contact us at:</p>
                <div className="bg-purple-900/30 p-4 rounded-lg">
                  <p>Email: legal@mindforgeacademy.com</p>
                  <p>Address: Mind Forge Academy Legal Team</p>
                </div>
              </div>
            </section>
          </div>

          <div className="mt-8 text-center">
            <Link href="/">
              <Button className="bg-purple-600 hover:bg-purple-700">Back to Mind Forge Academy</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
