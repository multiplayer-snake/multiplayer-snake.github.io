import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Privacy Policy
            </h1>
            <p className="text-purple-200">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          <div className="prose prose-invert max-w-none space-y-6 text-white">
            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">1. Information We Collect</h2>
              <div className="space-y-4 text-purple-100">
                <h3 className="text-lg font-semibold text-purple-200">Personal Information</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Name and email address when you create an account</li>
                  <li>Profile information you choose to provide</li>
                  <li>Learning preferences and progress data</li>
                </ul>

                <h3 className="text-lg font-semibold text-purple-200">Usage Information</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Learning session data and performance metrics</li>
                  <li>Time spent on different subjects and difficulty levels</li>
                  <li>Achievement and progress tracking</li>
                  <li>Device and browser information</li>
                </ul>

                <h3 className="text-lg font-semibold text-purple-200">AI-Enhanced Learning Data</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Learning patterns and preferences for personalization</li>
                  <li>Response times and engagement metrics</li>
                  <li>Adaptive difficulty adjustments</li>
                  <li>Content recommendations based on your learning style</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">2. How We Use Your Information</h2>
              <ul className="list-disc list-inside space-y-2 ml-4 text-purple-100">
                <li>Provide and improve our educational services</li>
                <li>Personalize your learning experience using AI</li>
                <li>Track your progress and achievements</li>
                <li>Send you relevant notifications and updates</li>
                <li>Analyze usage patterns to enhance our platform</li>
                <li>Ensure platform security and prevent fraud</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">3. AI and Machine Learning</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Mind Forge Academy uses advanced AI to create a personalized learning experience. Our AI systems
                  analyze your learning patterns, preferences, and performance to:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Generate questions tailored to your skill level</li>
                  <li>Adapt content difficulty in real-time</li>
                  <li>Recommend optimal study schedules</li>
                  <li>Provide personalized feedback and insights</li>
                </ul>
                <p>
                  All AI processing is designed to enhance your learning while maintaining your privacy and data
                  security.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">4. Data Sharing and Disclosure</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  We do not sell your personal information. We may share your information only in these circumstances:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>With your explicit consent</li>
                  <li>To comply with legal obligations</li>
                  <li>To protect our rights and prevent fraud</li>
                  <li>
                    With service providers who help us operate our platform (under strict confidentiality agreements)
                  </li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">5. Data Security</h2>
              <div className="space-y-4 text-purple-100">
                <p>We implement industry-standard security measures to protect your data:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Encryption of data in transit and at rest</li>
                  <li>Regular security audits and updates</li>
                  <li>Access controls and authentication systems</li>
                  <li>Secure cloud infrastructure with Supabase</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">6. Your Rights</h2>
              <div className="space-y-4 text-purple-100">
                <p>You have the right to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Access your personal data</li>
                  <li>Correct inaccurate information</li>
                  <li>Delete your account and data</li>
                  <li>Export your learning data</li>
                  <li>Opt out of certain data processing</li>
                  <li>Control notification preferences</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">7. Cookies and Tracking</h2>
              <div className="space-y-4 text-purple-100">
                <p>We use cookies and similar technologies to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Remember your login and preferences</li>
                  <li>Analyze platform usage and performance</li>
                  <li>Provide personalized content recommendations</li>
                  <li>Ensure platform security</li>
                </ul>
                <p>You can control cookie settings through your browser preferences.</p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">8. Children's Privacy</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Mind Forge Academy is designed for users 13 years and older. We do not knowingly collect personal
                  information from children under 13. If we become aware that we have collected such information, we
                  will delete it promptly.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">9. International Data Transfers</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  Your data may be processed in countries other than your own. We ensure appropriate safeguards are in
                  place to protect your information in accordance with applicable data protection laws.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">10. Changes to This Policy</h2>
              <div className="space-y-4 text-purple-100">
                <p>
                  We may update this Privacy Policy from time to time. We will notify you of any material changes by
                  email or through our platform. Your continued use of Mind Forge Academy after such changes constitutes
                  acceptance of the updated policy.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-300 mb-4">11. Contact Us</h2>
              <div className="space-y-4 text-purple-100">
                <p>If you have questions about this Privacy Policy or our data practices, please contact us at:</p>
                <div className="bg-purple-900/30 p-4 rounded-lg">
                  <p>Email: privacy@mindforgeacademy.com</p>
                  <p>Address: Mind Forge Academy Privacy Team</p>
                </div>
              </div>
            </section>
          </div>

          <div className="mt-8 text-center">
            <Link href="/">
              <Button className="bg-purple-600 hover:bg-purple-700">Back to Mind Forge Academy</Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
