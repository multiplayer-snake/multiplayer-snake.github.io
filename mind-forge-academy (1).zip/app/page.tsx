"use client"

import { useAuth } from "@/hooks/use-auth"
import AuthForm from "@/components/auth/auth-form"
import GameEngine from "@/components/game-engine"
import { GameProvider } from "@/contexts/game-context"
import { AudioProvider } from "@/contexts/audio-context"

export default function Home() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-2xl animate-pulse">Loading Mind Forge Academy...</div>
      </div>
    )
  }

  if (!user) {
    return <AuthForm />
  }

  return (
    <AudioProvider>
      <GameProvider>
        <GameEngine />
      </GameProvider>
    </AudioProvider>
  )
}
