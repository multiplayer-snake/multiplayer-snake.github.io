import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({
      cookies: () => cookieStore,
      supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL!,
      supabaseKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    })

    try {
      const { data, error } = await supabase.auth.exchangeCodeForSession(code)

      if (error) {
        console.error("Auth callback error:", error)
        return NextResponse.redirect(`${requestUrl.origin}/auth/error?message=${encodeURIComponent(error.message)}`)
      }

      if (data.user) {
        // Check if user profile exists, if not create it
        const { data: existingProfile } = await supabase.from("users").select("id").eq("id", data.user.id).single()

        if (!existingProfile) {
          // Create user profile with secret psychological data
          const assignABTestGroup = () => {
            const groups = ["control", "gamified", "social", "achievement", "curiosity"]
            return groups[Math.floor(Math.random() * groups.length)]
          }

          const generatePsychologicalProfile = () => {
            return {
              motivationType: Math.random() > 0.5 ? "intrinsic" : "extrinsic",
              competitiveLevel: Math.floor(Math.random() * 10) + 1,
              socialInfluence: Math.floor(Math.random() * 10) + 1,
              achievementOriented: Math.random() > 0.3,
              curiosityDriven: Math.random() > 0.4,
              lossAversion: Math.floor(Math.random() * 10) + 1,
              instantGratification: Math.floor(Math.random() * 10) + 1,
              streakMotivation: Math.random() > 0.6,
              socialProofSensitive: Math.random() > 0.5,
              challengeSeeker: Math.random() > 0.4,
            }
          }

          // Extract first name from user metadata
          const fullName = data.user.user_metadata?.full_name || data.user.user_metadata?.name || "Anonymous User"
          const firstName = fullName.split(" ")[0] || "genius"

          const { error: insertError } = await supabase.from("users").insert({
            id: data.user.id,
            email: data.user.email!,
            full_name: fullName,
            first_name: firstName,
            avatar_url: data.user.user_metadata?.avatar_url || data.user.user_metadata?.picture,
            ab_test_group: assignABTestGroup(),
            psychological_profile: generatePsychologicalProfile(),
            learning_style: ["visual", "auditory", "kinesthetic"][Math.floor(Math.random() * 3)],
            notification_preferences: {
              dailyReminders: true,
              streakWarnings: true,
              socialUpdates: true,
              achievements: true,
              challenges: true,
            },
          })

          if (insertError) {
            console.error("Error creating user profile:", insertError)
          }
        } else {
          // Update last active for existing user
          await supabase.from("users").update({ last_active: new Date().toISOString() }).eq("id", data.user.id)
        }
      }

      // Redirect to main app
      return NextResponse.redirect(`${requestUrl.origin}`)
    } catch (error) {
      console.error("Unexpected auth error:", error)
      return NextResponse.redirect(`${requestUrl.origin}/auth/error?message=Authentication failed`)
    }
  }

  // No code present, redirect to home
  return NextResponse.redirect(`${requestUrl.origin}`)
}
