"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function VerifyEmail() {
  const [verifying, setVerifying] = useState(true)
  const [verified, setVerified] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const searchParams = useSearchParams()

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        const token = searchParams.get("token")
        const type = searchParams.get("type")

        if (type === "signup" && token) {
          const { error } = await supabase.auth.verifyOtp({
            token_hash: token,
            type: "signup",
          })

          if (error) {
            setError(error.message)
          } else {
            setVerified(true)
          }
        } else {
          setError("Invalid verification link")
        }
      } catch (err: any) {
        setError(err.message || "Verification failed")
      } finally {
        setVerifying(false)
      }
    }

    verifyEmail()
  }, [searchParams])

  if (verifying) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 text-center">
          <div className="text-6xl mb-4 animate-spin">⚡</div>
          <h1 className="text-2xl font-bold text-white mb-4">Verifying Email</h1>
          <p className="text-purple-300">Please wait while we verify your email...</p>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 text-center">
        {verified ? (
          <>
            <div className="text-6xl mb-4">✅</div>
            <h1 className="text-2xl font-bold text-white mb-4">Email Verified!</h1>
            <p className="text-green-300 mb-6">
              Your account has been successfully verified. Welcome to Mind Forge Academy!
            </p>
            <Link href="/">
              <Button className="w-full bg-green-600 hover:bg-green-700">Start Learning</Button>
            </Link>
          </>
        ) : (
          <>
            <div className="text-6xl mb-4">❌</div>
            <h1 className="text-2xl font-bold text-white mb-4">Verification Failed</h1>
            <p className="text-red-300 mb-6">{error}</p>
            <Link href="/">
              <Button className="w-full bg-purple-600 hover:bg-purple-700">Try Again</Button>
            </Link>
          </>
        )}
      </Card>
    </div>
  )
}
