import { type NextRequest, NextResponse } from "next/server"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { questionManager } from "@/lib/question-manager"

export async function GET(request: NextRequest) {
  try {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Verify user authentication
    const {
      data: { session },
      error: authError,
    } = await supabase.auth.getSession()

    if (authError || !session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const subjectId = searchParams.get("subjectId")
    const questionCacheId = searchParams.get("questionCacheId")

    if (questionCacheId) {
      // Get analytics for a specific question
      const analysis = await questionManager.analyzeQuestionEffectiveness(questionCacheId)
      return NextResponse.json({ success: true, analysis })
    }

    if (subjectId) {
      // Get analytics for a subject
      const { data: analytics, error } = await supabase
        .from("question_performance_summary")
        .select("*")
        .eq("subject_id", subjectId)
        .order("accuracy_rate", { ascending: false })

      if (error) {
        throw error
      }

      return NextResponse.json({ success: true, analytics })
    }

    // Get overall analytics for the user
    const { data: userStats, error: statsError } = await supabase
      .from("user_question_history")
      .select(`
        *,
        question_cache(
          subject_id,
          question_data
        )
      `)
      .eq("user_id", session.user.id)
      .order("created_at", { ascending: false })
      .limit(100)

    if (statsError) {
      throw statsError
    }

    // Calculate user analytics
    const totalQuestions = userStats?.length || 0
    const correctAnswers = userStats?.filter((q) => q.is_correct).length || 0
    const averageResponseTime = userStats?.reduce((sum, q) => sum + q.response_time_seconds, 0) / totalQuestions || 0

    const subjectBreakdown = userStats?.reduce((acc: any, q) => {
      const subjectId = q.question_cache?.subject_id
      if (!subjectId) return acc

      if (!acc[subjectId]) {
        acc[subjectId] = { total: 0, correct: 0, avgTime: 0 }
      }

      acc[subjectId].total++
      if (q.is_correct) acc[subjectId].correct++
      acc[subjectId].avgTime =
        (acc[subjectId].avgTime * (acc[subjectId].total - 1) + q.response_time_seconds) / acc[subjectId].total

      return acc
    }, {})

    return NextResponse.json({
      success: true,
      analytics: {
        total_questions: totalQuestions,
        correct_answers: correctAnswers,
        accuracy_rate: totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0,
        average_response_time: averageResponseTime,
        subject_breakdown: subjectBreakdown,
      },
    })
  } catch (error: any) {
    console.error("Error in analytics API:", error)
    return NextResponse.json(
      {
        error: "Failed to get analytics",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
