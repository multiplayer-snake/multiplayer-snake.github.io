import { type NextRequest, NextResponse } from "next/server"
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { questionManager } from "@/lib/question-manager"

export async function POST(request: NextRequest) {
  try {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient({ cookies: () => cookieStore })

    // Verify user authentication
    const {
      data: { session },
      error: authError,
    } = await supabase.auth.getSession()

    if (authError || !session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { subjectId, count = 10, difficulty, adaptiveMode = false } = body

    if (!subjectId) {
      return NextResponse.json({ error: "Subject ID is required" }, { status: 400 })
    }

    // Log the generation request
    await supabase.from("question_generation_logs").insert({
      user_id: session.user.id,
      subject_id: subjectId,
      generation_request: {
        count,
        difficulty,
        adaptiveMode,
        timestamp: new Date().toISOString(),
      },
      groq_model_used: "llama-3.1-70b-versatile",
    })

    let questions
    const startTime = Date.now()

    try {
      if (adaptiveMode) {
        const question = await questionManager.getAdaptiveQuestion(subjectId, session.user.id)
        questions = [question]
      } else {
        questions = await questionManager.getQuestionsForSubject(subjectId, session.user.id, count, {
          difficulty,
          adaptToUser: true,
        })
      }

      const generationTime = Date.now() - startTime

      // Log successful generation
      await supabase.from("question_generation_logs").insert({
        user_id: session.user.id,
        subject_id: subjectId,
        generation_request: { count, difficulty, adaptiveMode },
        generation_response: {
          questions_generated: questions.length,
          generation_time_ms: generationTime,
        },
        groq_model_used: "llama-3.1-70b-versatile",
        generation_time_ms: generationTime,
        success: true,
      })

      return NextResponse.json({
        success: true,
        questions,
        metadata: {
          count: questions.length,
          generation_time_ms: generationTime,
          adaptive_mode: adaptiveMode,
        },
      })
    } catch (error: any) {
      const generationTime = Date.now() - startTime

      // Log failed generation
      await supabase.from("question_generation_logs").insert({
        user_id: session.user.id,
        subject_id: subjectId,
        generation_request: { count, difficulty, adaptiveMode },
        groq_model_used: "llama-3.1-70b-versatile",
        generation_time_ms: generationTime,
        success: false,
        error_message: error.message,
      })

      throw error
    }
  } catch (error: any) {
    console.error("Error in question generation API:", error)
    return NextResponse.json(
      {
        error: "Failed to generate questions",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
