"use client"

import { useGame } from "@/contexts/game-context"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export default function ProgressHUD() {
  const { state } = useGame()

  const xpToNextLevel = 1000 * state.level
  const xpProgress = ((state.xp % xpToNextLevel) / xpToNextLevel) * 100
  const accuracy = state.totalAnswered > 0 ? (state.correctAnswers / state.totalAnswered) * 100 : 0

  return (
    <div className="bg-black/30 backdrop-blur-sm border-b border-purple-500/30 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Top Row - Main Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{state.level}</div>
            <div className="text-purple-300 text-sm">Level</div>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-400">{state.xp.toLocaleString()}</div>
            <div className="text-purple-300 text-sm">XP</div>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">{state.streak}</div>
            <div className="text-purple-300 text-sm">Streak</div>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">{accuracy.toFixed(1)}%</div>
            <div className="text-purple-300 text-sm">Accuracy</div>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between text-sm text-purple-300 mb-1">
            <span>Level {state.level}</span>
            <span>
              {state.xp % xpToNextLevel} / {xpToNextLevel} XP
            </span>
          </div>
          <Progress value={xpProgress} className="h-3" />
        </div>

        {/* Badges and Status */}
        <div className="flex flex-wrap gap-2 justify-center">
          {state.geniusMode && (
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black animate-pulse">
              GENIUS MODE
            </Badge>
          )}

          {state.bonusMultiplier > 1 && (
            <Badge className="bg-yellow-600 animate-bounce">{state.bonusMultiplier.toFixed(1)}x BONUS</Badge>
          )}

          {state.momentum > 1.5 && <Badge className="bg-green-600">HIGH FLOW</Badge>}

          {state.streak >= 10 && <Badge className="bg-purple-600">ON FIRE 🔥</Badge>}

          <Badge variant="outline" className="text-purple-300 border-purple-500">
            {state.masteryPoints} Mastery Points
          </Badge>

          <Badge variant="outline" className="text-blue-300 border-blue-500">
            {state.achievements.length} Achievements
          </Badge>
        </div>
      </div>
    </div>
  )
}
