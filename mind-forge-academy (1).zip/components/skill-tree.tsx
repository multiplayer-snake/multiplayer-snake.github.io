"use client"

import { useGame } from "@/contexts/game-context"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface SkillTreeProps {
  onClose: () => void
}

const SKILL_CATEGORIES = [
  {
    name: "Mathematics",
    color: "bg-blue-500",
    skills: ["Basic Arithmetic", "Algebra", "Geometry", "Calculus"],
    unlockCost: [0, 100, 250, 500],
  },
  {
    name: "Science",
    color: "bg-green-500",
    skills: ["Physics", "Chemistry", "Biology", "Astronomy"],
    unlockCost: [0, 150, 300, 600],
  },
  {
    name: "Geography",
    color: "bg-yellow-500",
    skills: ["Countries", "Capitals", "Landmarks", "Climate"],
    unlockCost: [0, 80, 200, 400],
  },
  {
    name: "History",
    color: "bg-red-500",
    skills: ["Ancient", "Medieval", "Modern", "Contemporary"],
    unlockCost: [0, 120, 280, 550],
  },
  {
    name: "Literature",
    color: "bg-purple-500",
    skills: ["Classics", "Poetry", "Drama", "Modern Fiction"],
    unlockCost: [0, 100, 240, 480],
  },
]

export default function SkillTree({ onClose }: SkillTreeProps) {
  const { state, dispatch } = useGame()

  const getSkillLevel = (category: string, skillIndex: number) => {
    return state.skillTree[`${category}_${skillIndex}`] || 0
  }

  const canUnlockSkill = (category: string, skillIndex: number, cost: number) => {
    const currentLevel = getSkillLevel(category, skillIndex)
    return currentLevel === 0 && state.masteryPoints >= cost
  }

  const unlockSkill = (category: string, skillIndex: number, cost: number) => {
    if (canUnlockSkill(category, skillIndex, cost)) {
      // This would dispatch an action to unlock the skill
      // For now, we'll just show the visual feedback
    }
  }

  return (
    <Card className="w-full max-w-6xl mx-auto bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-white">Neural Pathways</h2>
        <div className="flex items-center space-x-4">
          <Badge className="bg-purple-600 text-lg px-4 py-2">{state.masteryPoints} Mastery Points</Badge>
          <Button onClick={onClose} variant="outline">
            Close
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SKILL_CATEGORIES.map((category) => (
          <div key={category.name} className="space-y-4">
            <h3 className="text-xl font-bold text-white flex items-center">
              <div className={`w-4 h-4 rounded-full ${category.color} mr-2`}></div>
              {category.name}
            </h3>

            <div className="space-y-3">
              {category.skills.map((skill, index) => {
                const level = getSkillLevel(category.name, index)
                const cost = category.unlockCost[index]
                const isUnlocked = level > 0 || cost === 0
                const canUnlock = canUnlockSkill(category.name, index, cost)

                return (
                  <div
                    key={skill}
                    className={`p-3 rounded-lg border-2 transition-all duration-300 ${
                      isUnlocked
                        ? `${category.color} border-transparent`
                        : canUnlock
                          ? "bg-gray-700 border-yellow-400 cursor-pointer hover:bg-gray-600"
                          : "bg-gray-800 border-gray-600"
                    }`}
                    onClick={() => canUnlock && unlockSkill(category.name, index, cost)}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-white font-medium">{skill}</span>
                      {!isUnlocked && <span className="text-yellow-400 text-sm">{cost} MP</span>}
                    </div>

                    {isUnlocked && (
                      <div className="mt-2">
                        <div className="w-full bg-gray-600 rounded-full h-2">
                          <div
                            className="bg-white h-2 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(level * 25, 100)}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-300 mt-1">Level {level}/4</div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Fractured Gems Section */}
      {state.fracturedGems.length > 0 && (
        <div className="mt-8 p-6 bg-red-900/30 rounded-lg border border-red-500/50">
          <h3 className="text-xl font-bold text-red-400 mb-4">Fractured Knowledge Gems</h3>
          <div className="flex flex-wrap gap-2">
            {state.fracturedGems.map((gem, index) => (
              <Badge
                key={index}
                className="bg-red-600 hover:bg-red-500 cursor-pointer"
                onClick={() => dispatch({ type: "REPAIR_GEM", payload: gem })}
              >
                Repair {gem} 💎
              </Badge>
            ))}
          </div>
          <p className="text-red-300 text-sm mt-2">
            Click to repair fractured gems and restore your knowledge pathways!
          </p>
        </div>
      )}
    </Card>
  )
}
