"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Brain, Target, Clock, TrendingUp, Zap } from "lucide-react"

interface QuestionAnalyticsDashboardProps {
  userId: string
  subjectId?: string
}

export default function QuestionAnalyticsDashboard({ userId, subjectId }: QuestionAnalyticsDashboardProps) {
  const [analytics, setAnalytics] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchAnalytics()
  }, [userId, subjectId])

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (subjectId) params.append("subjectId", subjectId)

      const response = await fetch(`/api/questions/analytics?${params}`)
      const data = await response.json()

      if (!data.success) {
        throw new Error(data.error)
      }

      setAnalytics(data.analytics)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
        <div className="text-center text-white">Loading analytics...</div>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="bg-red-900/20 border-red-500/30 p-8">
        <div className="text-red-400">Error loading analytics: {error}</div>
      </Card>
    )
  }

  if (!analytics) {
    return (
      <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
        <div className="text-center text-white">No analytics data available</div>
      </Card>
    )
  }

  const subjectData = Object.entries(analytics.subject_breakdown || {}).map(([subjectId, data]: [string, any]) => ({
    subject: subjectId.slice(0, 8),
    accuracy: (data.correct / data.total) * 100,
    avgTime: data.avgTime,
    total: data.total,
  }))

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-white">{analytics.total_questions}</div>
              <div className="text-purple-300 text-sm">Total Questions</div>
            </div>
            <Brain className="w-8 h-8 text-purple-400" />
          </div>
        </Card>

        <Card className="bg-black/40 backdrop-blur-sm border-green-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-green-400">{analytics.accuracy_rate.toFixed(1)}%</div>
              <div className="text-green-300 text-sm">Accuracy Rate</div>
            </div>
            <Target className="w-8 h-8 text-green-400" />
          </div>
        </Card>

        <Card className="bg-black/40 backdrop-blur-sm border-blue-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-400">{analytics.average_response_time.toFixed(1)}s</div>
              <div className="text-blue-300 text-sm">Avg Response Time</div>
            </div>
            <Clock className="w-8 h-8 text-blue-400" />
          </div>
        </Card>

        <Card className="bg-black/40 backdrop-blur-sm border-yellow-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-yellow-400">{analytics.correct_answers}</div>
              <div className="text-yellow-300 text-sm">Correct Answers</div>
            </div>
            <TrendingUp className="w-8 h-8 text-yellow-400" />
          </div>
        </Card>
      </div>

      {/* Subject Performance Chart */}
      {subjectData.length > 0 && (
        <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-6">
          <div className="flex items-center mb-4">
            <Zap className="w-5 h-5 text-purple-400 mr-2" />
            <h3 className="text-xl font-bold text-white">Subject Performance</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={subjectData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="subject" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1F2937",
                  border: "1px solid #6B7280",
                  borderRadius: "8px",
                }}
                labelStyle={{ color: "#F3F4F6" }}
              />
              <Bar dataKey="accuracy" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Performance Insights */}
      <Card className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-6">
        <h3 className="text-xl font-bold text-white mb-4">AI-Powered Insights</h3>
        <div className="space-y-4">
          {analytics.accuracy_rate > 80 && (
            <div className="flex items-center p-3 bg-green-900/20 border border-green-500/30 rounded-lg">
              <div className="text-green-400 mr-3">🎯</div>
              <div className="text-green-300">Excellent accuracy! You're ready for more challenging questions.</div>
            </div>
          )}

          {analytics.average_response_time < 15 && (
            <div className="flex items-center p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg">
              <div className="text-blue-400 mr-3">⚡</div>
              <div className="text-blue-300">Lightning fast responses! Your knowledge recall is impressive.</div>
            </div>
          )}

          {analytics.accuracy_rate < 60 && (
            <div className="flex items-center p-3 bg-yellow-900/20 border border-yellow-500/30 rounded-lg">
              <div className="text-yellow-400 mr-3">💡</div>
              <div className="text-yellow-300">
                Consider reviewing fundamentals. Adaptive questions will help strengthen weak areas.
              </div>
            </div>
          )}

          <div className="flex items-center p-3 bg-purple-900/20 border border-purple-500/30 rounded-lg">
            <div className="text-purple-400 mr-3">🧠</div>
            <div className="text-purple-300">
              All questions are generated by Groq AI and adapted to your learning style and performance.
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
