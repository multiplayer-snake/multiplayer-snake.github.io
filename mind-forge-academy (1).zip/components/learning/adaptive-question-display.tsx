"use client"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/hooks/use-auth"
import { useQuestions } from "@/hooks/use-questions"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { supabase } from "@/lib/supabase"

interface AdaptiveQuestionDisplayProps {
  subjectId: string
  onComplete: () => void
}

export default function AdaptiveQuestionDisplay({ subjectId, onComplete }: AdaptiveQuestionDisplayProps) {
  const { user, userProfile } = useAuth()
  const { currentQuestion, loading, questionIndex, totalQuestions, nextQuestion, recordAnswer } = useQuestions(
    subjectId,
    user?.id || "",
  )

  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(30)
  const [sessionStartTime] = useState(Date.now())
  const [questionStartTime, setQuestionStartTime] = useState(Date.now())
  const [streak, setStreak] = useState(0)
  const [xpGained, setXpGained] = useState(0)
  const [showPsychTrigger, setShowPsychTrigger] = useState(false)

  const timerRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    if (currentQuestion) {
      setQuestionStartTime(Date.now())
      setTimeLeft(30)
      setSelectedAnswer(null)
      setShowResult(false)

      // Start timer
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleAnswer(-1) // Time's up
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [currentQuestion])

  // Secretly trigger psychological elements based on user profile
  useEffect(() => {
    if (currentQuestion?.psychological_triggers && userProfile) {
      const triggers = currentQuestion.psychological_triggers

      // Show social proof for social users
      if (triggers.includes("social_proof") && Math.random() < 0.3) {
        setShowPsychTrigger(true)
        setTimeout(() => setShowPsychTrigger(false), 3000)
      }
    }
  }, [currentQuestion, userProfile])

  const handleAnswer = async (answerIndex: number) => {
    if (showResult || !currentQuestion) return

    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    const timeSpent = (Date.now() - questionStartTime) / 1000
    const isCorrect = answerIndex === currentQuestion.correct_answer

    setSelectedAnswer(answerIndex)
    setShowResult(true)

    // Calculate XP with psychological bonuses
    let baseXP = isCorrect ? 100 : 25
    const timeBonus = Math.max(0, (30 - timeSpent) / 30) * 50
    const streakBonus = streak * 10

    // Secret psychological multipliers
    if (userProfile?.psychological_profile?.achievementOriented && isCorrect) {
      baseXP *= 1.2 // Achievement-oriented users get more XP
    }

    const totalXP = Math.floor(baseXP + timeBonus + streakBonus)
    setXpGained(totalXP)

    // Update streak
    if (isCorrect) {
      setStreak((prev) => prev + 1)
    } else {
      setStreak(0)
    }

    // Record answer for A/B testing
    await recordAnswer(answerIndex, timeSpent, isCorrect)

    // Update user progress
    await updateUserProgress(isCorrect, totalXP, timeSpent)

    // Auto-advance after showing result
    setTimeout(
      () => {
        if (questionIndex < totalQuestions - 1) {
          nextQuestion()
        } else {
          onComplete()
        }
      },
      isCorrect ? 2000 : 3000,
    ) // Shorter delay for correct answers = more addictive
  }

  const updateUserProgress = async (isCorrect: boolean, xp: number, timeSpent: number) => {
    if (!user) return

    try {
      // Update user stats
      await supabase
        .from("users")
        .update({
          total_xp: (userProfile?.total_xp || 0) + xp,
          current_streak: isCorrect ? (userProfile?.current_streak || 0) + 1 : 0,
          last_active: new Date().toISOString(),
        })
        .eq("id", user.id)

      // Update subject progress
      const { data: progress } = await supabase
        .from("user_progress")
        .select("*")
        .eq("user_id", user.id)
        .eq("subject_id", subjectId)
        .single()

      if (progress) {
        await supabase
          .from("user_progress")
          .update({
            questions_answered: progress.questions_answered + 1,
            questions_correct: progress.questions_correct + (isCorrect ? 1 : 0),
            current_streak: isCorrect ? progress.current_streak + 1 : 0,
            last_studied: new Date().toISOString(),
            time_spent_minutes: progress.time_spent_minutes + timeSpent / 60,
          })
          .eq("id", progress.id)
      } else {
        await supabase.from("user_progress").insert({
          user_id: user.id,
          subject_id: subjectId,
          questions_answered: 1,
          questions_correct: isCorrect ? 1 : 0,
          current_streak: isCorrect ? 1 : 0,
          last_studied: new Date().toISOString(),
          time_spent_minutes: timeSpent / 60,
        })
      }
    } catch (error) {
      console.error("Error updating progress:", error)
    }
  }

  const getButtonClass = (index: number) => {
    let baseClass =
      "w-full p-4 text-left rounded-lg font-medium transition-all duration-200 transform hover:scale-105 relative overflow-hidden "

    if (showResult) {
      if (index === currentQuestion?.correct_answer) {
        baseClass +=
          "bg-gradient-to-r from-green-500 to-emerald-500 text-white animate-pulse shadow-lg shadow-green-500/50 "
      } else if (index === selectedAnswer && index !== currentQuestion?.correct_answer) {
        baseClass += "bg-gradient-to-r from-red-500 to-rose-500 text-white shadow-lg shadow-red-500/50 "
      } else {
        baseClass += "bg-gray-600 text-gray-300 "
      }
    } else {
      // Secretly use different colors based on psychological profile
      if (userProfile?.psychological_profile?.competitiveLevel > 7) {
        baseClass +=
          "bg-gradient-to-r from-red-700 to-orange-600 hover:from-red-600 hover:to-orange-500 text-white hover:shadow-lg hover:shadow-red-500/30 "
      } else if (userProfile?.psychological_profile?.achievementOriented) {
        baseClass +=
          "bg-gradient-to-r from-yellow-700 to-amber-600 hover:from-yellow-600 hover:to-amber-500 text-white hover:shadow-lg hover:shadow-yellow-500/30 "
      } else {
        baseClass +=
          "bg-gradient-to-r from-gray-700 to-gray-600 hover:from-purple-600 hover:to-blue-600 text-white hover:shadow-lg hover:shadow-purple-500/30 "
      }
    }

    return baseClass
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-white text-xl animate-pulse">Loading personalized questions...</div>
      </div>
    )
  }

  if (!currentQuestion) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-white text-xl">No questions available</div>
      </div>
    )
  }

  return (
    <div className="relative">
      <Card className="w-full max-w-4xl mx-auto bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 relative overflow-hidden">
        {/* Secret psychological trigger overlays */}
        {showPsychTrigger && (
          <div className="absolute top-4 right-4 bg-green-600/20 backdrop-blur-sm rounded-lg p-2 text-xs animate-pulse">
            <div className="text-green-400 font-bold">👥 Live Activity</div>
            <div className="text-white">{Math.floor(Math.random() * 50) + 10} students answering this now</div>
          </div>
        )}

        {/* Progress and Stats */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-4">
              <span className="text-purple-300 font-semibold">
                Question {questionIndex + 1} of {totalQuestions}
              </span>
              {streak > 0 && <Badge className="bg-orange-600 animate-bounce">🔥 {streak} streak</Badge>}
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-white font-mono text-lg bg-black/50 px-3 py-1 rounded">{timeLeft}s</div>
              <Badge className="bg-yellow-600">{userProfile?.total_xp || 0} XP</Badge>
            </div>
          </div>

          <Progress value={(questionIndex / totalQuestions) * 100} className="h-3 mb-4" />
        </div>

        {/* Question */}
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 leading-relaxed">
          {currentQuestion.question_text}
        </h2>

        {/* Answer Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {currentQuestion.options.map((option: string, index: number) => (
            <Button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={getButtonClass(index)}
              variant="ghost"
            >
              <div className="relative z-10 flex items-center">
                <span className="mr-3 font-bold text-lg bg-white/20 w-8 h-8 rounded-full flex items-center justify-center">
                  {String.fromCharCode(65 + index)}
                </span>
                {option}
              </div>
            </Button>
          ))}
        </div>

        {/* Result Display */}
        {showResult && (
          <div className="mt-6 p-6 rounded-lg bg-black/50 text-center border-2 border-purple-500/50">
            {selectedAnswer === currentQuestion.correct_answer ? (
              <div className="space-y-2">
                <div className="text-green-400 font-bold text-2xl animate-bounce">🎉 CORRECT!</div>
                <div className="text-yellow-400 text-lg">+{xpGained} XP</div>
                {streak > 1 && <div className="text-orange-400 font-bold">🔥 {streak} in a row!</div>}
                <div className="text-purple-300 text-sm">{currentQuestion.explanation}</div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-red-400 font-bold text-xl">Not quite right</div>
                <div className="text-white">
                  The answer was{" "}
                  <span className="font-bold text-green-400">
                    {String.fromCharCode(65 + currentQuestion.correct_answer)}
                  </span>
                </div>
                <div className="text-purple-300 text-sm">{currentQuestion.explanation}</div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Secret motivational elements based on psychological profile */}
      {userProfile?.psychological_profile?.socialProofSensitive && Math.random() < 0.1 && (
        <div className="fixed bottom-20 right-4 bg-blue-600/90 backdrop-blur-sm text-white p-3 rounded-lg text-sm animate-slide-in-right">
          🏆 You're in the top {Math.floor(Math.random() * 20) + 5}% of learners!
        </div>
      )}
    </div>
  )
}
