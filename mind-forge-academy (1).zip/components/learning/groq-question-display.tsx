"use client"

import { useState, useEffect, useRef } from "react"
import { useAuth } from "@/hooks/use-auth"
import { useQuestions } from "@/hooks/use-questions"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Loader2, Brain, Zap, Target, Clock } from "lucide-react"

interface GroqQuestionDisplayProps {
  subjectId: string
  onComplete?: () => void
  adaptiveMode?: boolean
}

export default function GroqQuestionDisplay({ subjectId, onComplete, adaptiveMode = false }: GroqQuestionDisplayProps) {
  const { user } = useAuth()
  const {
    currentQuestion,
    loading,
    error,
    questionIndex,
    totalQuestions,
    progress,
    nextQuestion,
    recordAnswer,
    getAdaptiveQuestion,
    loadQuestions,
  } = useQuestions(subjectId, user?.id || "", { adaptiveMode })

  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeLeft, setTimeLeft] = useState(30)
  const [questionStartTime, setQuestionStartTime] = useState(Date.now())
  const [streak, setStreak] = useState(0)
  const [sessionStats, setSessionStats] = useState({
    correct: 0,
    total: 0,
    averageTime: 0,
  })

  const timerRef = useRef<NodeJS.Timeout>()

  // Start timer when question changes
  useEffect(() => {
    if (currentQuestion) {
      setQuestionStartTime(Date.now())
      setTimeLeft(currentQuestion.estimated_time_seconds || 30)
      setSelectedAnswer(null)
      setShowResult(false)

      // Clear existing timer
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }

      // Start new timer
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleAnswer(-1) // Time's up
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [currentQuestion])

  const handleAnswer = async (answerIndex: number) => {
    if (showResult || !currentQuestion) return

    // Stop timer
    if (timerRef.current) {
      clearInterval(timerRef.current)
    }

    const responseTime = (Date.now() - questionStartTime) / 1000
    const isCorrect = answerIndex === currentQuestion.correct_answer
    const isTimeout = answerIndex === -1

    setSelectedAnswer(answerIndex)
    setShowResult(true)

    // Update session stats
    setSessionStats((prev) => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1,
      averageTime: (prev.averageTime * prev.total + responseTime) / (prev.total + 1),
    }))

    // Update streak
    if (isCorrect) {
      setStreak((prev) => prev + 1)
    } else {
      setStreak(0)
    }

    // Record the answer
    try {
      await recordAnswer(answerIndex, isCorrect, responseTime, {
        timeout: isTimeout,
        estimated_time: currentQuestion.estimated_time_seconds,
        bloom_level: currentQuestion.bloom_taxonomy_level,
        cognitive_load: currentQuestion.cognitive_load,
      })
    } catch (error) {
      console.error("Failed to record answer:", error)
    }

    // Auto-advance after showing result
    setTimeout(
      () => {
        if (adaptiveMode) {
          getAdaptiveQuestion()
        } else {
          if (questionIndex < totalQuestions - 1) {
            nextQuestion()
          } else {
            onComplete?.()
          }
        }
      },
      isCorrect ? 2000 : 3000,
    )
  }

  const getButtonClass = (index: number) => {
    let baseClass =
      "w-full p-4 text-left rounded-lg font-medium transition-all duration-200 transform hover:scale-105 relative overflow-hidden "

    if (showResult) {
      if (index === currentQuestion?.correct_answer) {
        baseClass +=
          "bg-gradient-to-r from-green-500 to-emerald-500 text-white animate-pulse shadow-lg shadow-green-500/50 "
      } else if (index === selectedAnswer && index !== currentQuestion?.correct_answer) {
        baseClass += "bg-gradient-to-r from-red-500 to-rose-500 text-white shadow-lg shadow-red-500/50 "
      } else {
        baseClass += "bg-gray-600 text-gray-300 "
      }
    } else {
      baseClass +=
        "bg-gradient-to-r from-purple-700 to-blue-600 hover:from-purple-600 hover:to-blue-500 text-white hover:shadow-lg hover:shadow-purple-500/30 "
    }

    return baseClass
  }

  const getDifficultyColor = (difficulty: number) => {
    if (difficulty <= 3) return "bg-green-600"
    if (difficulty <= 6) return "bg-yellow-600"
    if (difficulty <= 8) return "bg-orange-600"
    return "bg-red-600"
  }

  const getBloomLevelIcon = (level: string) => {
    switch (level?.toLowerCase()) {
      case "remember":
        return "🧠"
      case "understand":
        return "💡"
      case "apply":
        return "🔧"
      case "analyze":
        return "🔍"
      case "evaluate":
        return "⚖️"
      case "create":
        return "✨"
      default:
        return "📚"
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-500 mx-auto mb-4" />
          <div className="text-white text-xl">
            {adaptiveMode ? "Generating adaptive question..." : "Loading personalized questions..."}
          </div>
          <div className="text-purple-300 text-sm mt-2">Powered by Groq AI • Tailored to your learning style</div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Card className="bg-red-900/20 border-red-500/30 p-8 text-center">
          <div className="text-red-400 text-xl mb-4">⚠️ Error Loading Questions</div>
          <div className="text-red-300 mb-4">{error}</div>
          <Button
            onClick={() => (adaptiveMode ? getAdaptiveQuestion() : loadQuestions())}
            className="bg-red-600 hover:bg-red-700"
          >
            Try Again
          </Button>
        </Card>
      </div>
    )
  }

  if (!currentQuestion) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-white text-xl">No questions available</div>
      </div>
    )
  }

  return (
    <div className="relative">
      <Card className="w-full max-w-4xl mx-auto bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 relative overflow-hidden">
        {/* AI Generation Indicator */}
        <div className="absolute top-4 right-4 flex items-center space-x-2">
          <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
            <Brain className="w-3 h-3 mr-1" />
            Groq AI
          </Badge>
          {adaptiveMode && (
            <Badge className="bg-gradient-to-r from-green-600 to-teal-600 text-white">
              <Target className="w-3 h-3 mr-1" />
              Adaptive
            </Badge>
          )}
        </div>

        {/* Question Metadata */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-4">
              <span className="text-purple-300 font-semibold">
                {!adaptiveMode && `Question ${questionIndex + 1} of ${totalQuestions}`}
                {adaptiveMode && "Adaptive Question"}
              </span>
              <Badge className={getDifficultyColor(currentQuestion.difficulty)}>
                Level {currentQuestion.difficulty}/10
              </Badge>
              <Badge className="bg-blue-600">
                {getBloomLevelIcon(currentQuestion.bloom_taxonomy_level)} {currentQuestion.bloom_taxonomy_level}
              </Badge>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center text-white">
                <Clock className="w-4 h-4 mr-1" />
                <span className="font-mono text-lg">{timeLeft}s</span>
              </div>
              {streak > 0 && <Badge className="bg-orange-600 animate-bounce">🔥 {streak} streak</Badge>}
            </div>
          </div>

          {/* Progress Bar */}
          {!adaptiveMode && <Progress value={progress} className="h-3 mb-4" />}

          {/* Concept Tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {currentQuestion.concept_tags?.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-purple-300 border-purple-500">
                {tag}
              </Badge>
            ))}
          </div>
        </div>

        {/* Question */}
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 leading-relaxed">
          {currentQuestion.question_text}
        </h2>

        {/* Answer Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {currentQuestion.options.map((option: string, index: number) => (
            <Button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={getButtonClass(index)}
              variant="ghost"
            >
              <div className="relative z-10 flex items-center">
                <span className="mr-3 font-bold text-lg bg-white/20 w-8 h-8 rounded-full flex items-center justify-center">
                  {String.fromCharCode(65 + index)}
                </span>
                {option}
              </div>
            </Button>
          ))}
        </div>

        {/* Session Stats */}
        <div className="flex justify-between items-center text-sm mb-4">
          <div className="flex space-x-4">
            <div className="text-purple-300">
              Accuracy:{" "}
              <span className="text-green-400">
                {sessionStats.total > 0 ? Math.round((sessionStats.correct / sessionStats.total) * 100) : 0}%
              </span>
            </div>
            <div className="text-purple-300">
              Avg Time: <span className="text-blue-400">{sessionStats.averageTime.toFixed(1)}s</span>
            </div>
            <div className="text-purple-300">
              Cognitive Load: <span className="text-yellow-400">{currentQuestion.cognitive_load}/10</span>
            </div>
          </div>
        </div>

        {/* Result Display */}
        {showResult && (
          <div className="mt-6 p-6 rounded-lg bg-black/50 text-center border-2 border-purple-500/50">
            {selectedAnswer === currentQuestion.correct_answer ? (
              <div className="space-y-2">
                <div className="text-green-400 font-bold text-2xl animate-bounce">🎉 CORRECT!</div>
                <div className="text-purple-300 text-sm">{currentQuestion.explanation}</div>
                {streak > 1 && <div className="text-orange-400 font-bold">🔥 {streak} in a row!</div>}
              </div>
            ) : selectedAnswer === -1 ? (
              <div className="space-y-2">
                <div className="text-yellow-400 font-bold text-xl">⏰ Time's Up!</div>
                <div className="text-white">
                  The answer was{" "}
                  <span className="font-bold text-green-400">
                    {String.fromCharCode(65 + currentQuestion.correct_answer)}
                  </span>
                </div>
                <div className="text-purple-300 text-sm">{currentQuestion.explanation}</div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-red-400 font-bold text-xl">Not quite right</div>
                <div className="text-white">
                  The answer was{" "}
                  <span className="font-bold text-green-400">
                    {String.fromCharCode(65 + currentQuestion.correct_answer)}
                  </span>
                </div>
                <div className="text-purple-300 text-sm">{currentQuestion.explanation}</div>
              </div>
            )}
          </div>
        )}

        {/* AI Generation Info */}
        <div className="mt-6 p-4 bg-purple-900/20 rounded-lg border border-purple-500/30">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-purple-300">
                <Zap className="w-4 h-4 mr-1" />
                Generated by Groq AI
              </div>
              <div className="text-purple-300">Est. Time: {currentQuestion.estimated_time_seconds}s</div>
            </div>
            <div className="text-purple-300">Difficulty Calibrated to Your Level</div>
          </div>
        </div>
      </Card>
    </div>
  )
}
