"use client"

import { useAuth } from "./auth-provider"
import { useGame } from "@/contexts/game-context"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { useState } from "react"

export default function UserProfile() {
  const { user, signOut, updateUser } = useAuth()
  const { state } = useGame()
  const [showSettings, setShowSettings] = useState(false)

  if (!user) return null

  const updateNotificationPreference = (key: keyof typeof user.notificationPreferences, value: boolean) => {
    updateUser({
      notificationPreferences: {
        ...user.notificationPreferences,
        [key]: value,
      },
    })
  }

  return (
    <div className="absolute top-4 right-4 z-50">
      <div className="relative">
        {/* Profile Button */}
        <Button
          onClick={() => setShowSettings(!showSettings)}
          className="bg-black/40 backdrop-blur-sm border border-purple-500/30 hover:bg-black/60 p-2 rounded-full"
          variant="ghost"
        >
          <img src={user.picture || "/placeholder.svg"} alt={user.name} className="w-8 h-8 rounded-full" />
        </Button>

        {/* Profile Dropdown */}
        {showSettings && (
          <Card className="absolute top-12 right-0 w-80 bg-black/90 backdrop-blur-sm border-purple-500/30 p-4 text-white">
            {/* User Info */}
            <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-purple-500/30">
              <img src={user.picture || "/placeholder.svg"} alt={user.name} className="w-12 h-12 rounded-full" />
              <div>
                <div className="font-bold">{user.name}</div>
                <div className="text-sm text-purple-300">{user.email}</div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-400">{user.studyStreak}</div>
                <div className="text-xs text-purple-300">Day Streak</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{user.totalXP.toLocaleString()}</div>
                <div className="text-xs text-purple-300">Total XP</div>
              </div>
            </div>

            {/* Current Session Stats */}
            <div className="bg-purple-900/30 rounded-lg p-3 mb-4">
              <div className="text-sm font-semibold mb-2">Current Session</div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <div className="text-green-400 font-bold">{state.streak}</div>
                  <div className="text-purple-300">Streak</div>
                </div>
                <div>
                  <div className="text-blue-400 font-bold">{state.xp}</div>
                  <div className="text-purple-300">XP</div>
                </div>
                <div>
                  <div className="text-yellow-400 font-bold">{state.correctAnswers}</div>
                  <div className="text-purple-300">Correct</div>
                </div>
              </div>
            </div>

            {/* Notification Settings */}
            <div className="mb-4">
              <div className="text-sm font-semibold mb-3 flex items-center">🔔 Notification Settings</div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Daily Reminders</span>
                  <Switch
                    checked={user.notificationPreferences.dailyReminders}
                    onCheckedChange={(checked) => updateNotificationPreference("dailyReminders", checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Streak Warnings</span>
                  <Switch
                    checked={user.notificationPreferences.streakWarnings}
                    onCheckedChange={(checked) => updateNotificationPreference("streakWarnings", checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Social Updates</span>
                  <Switch
                    checked={user.notificationPreferences.socialUpdates}
                    onCheckedChange={(checked) => updateNotificationPreference("socialUpdates", checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Achievements</span>
                  <Switch
                    checked={user.notificationPreferences.achievements}
                    onCheckedChange={(checked) => updateNotificationPreference("achievements", checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Challenges</span>
                  <Switch
                    checked={user.notificationPreferences.challenges}
                    onCheckedChange={(checked) => updateNotificationPreference("challenges", checked)}
                  />
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2">
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700 text-sm"
                onClick={() => {
                  /* Open leaderboard */
                }}
              >
                🏆 View Leaderboard
              </Button>
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700 text-sm"
                onClick={() => {
                  /* Invite friends */
                }}
              >
                👥 Invite Friends
              </Button>
              <Button className="w-full bg-red-600 hover:bg-red-700 text-sm" onClick={signOut}>
                Sign Out
              </Button>
            </div>

            {/* Addictive Social Pressure */}
            <div className="mt-4 p-3 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/50 rounded-lg">
              <div className="text-yellow-400 font-bold text-xs mb-1">🔥 FRIENDS ACTIVITY</div>
              <div className="text-xs text-white">
                Sarah beat your high score! <br />
                Mike is on a {Math.floor(Math.random() * 20) + 10}-day streak!
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
