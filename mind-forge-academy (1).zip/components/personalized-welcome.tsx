"use client"

import { useAuth } from "@/hooks/use-auth"
import { useEffect, useState } from "react"

export default function PersonalizedWelcome() {
  const { user, userProfile } = useAuth()
  const [showWelcome, setShowWelcome] = useState(false)
  const [welcomeMessage, setWelcomeMessage] = useState("")

  useEffect(() => {
    if (user && userProfile) {
      const firstName = userProfile.first_name || "genius"
      const isNewSession = !sessionStorage.getItem("welcomeShown")

      if (isNewSession) {
        const messages = [
          `Welcome back, ${firstName}! 🧠`,
          `Hello ${firstName}, ready to expand your mind? 🚀`,
          `Great to see you again, ${firstName}! 💫`,
          `${firstName}, your learning journey continues! ⭐`,
          `Welcome, brilliant ${firstName}! 🌟`,
        ]

        setWelcomeMessage(messages[Math.floor(Math.random() * messages.length)])
        setShowWelcome(true)
        sessionStorage.setItem("welcomeShown", "true")

        // Auto-hide after 4 seconds
        setTimeout(() => setShowWelcome(false), 4000)
      }
    }
  }, [user, userProfile])

  if (!showWelcome) return null

  return (
    <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 animate-slide-in-down">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-full shadow-2xl border border-purple-400/50">
        <div className="text-center font-semibold">{welcomeMessage}</div>
      </div>
    </div>
  )
}
