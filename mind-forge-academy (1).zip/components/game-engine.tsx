"use client"

import { useGame } from "@/contexts/game-context"
import { useAudio } from "@/contexts/audio-context"
import EnhancedQuestionDisplay from "./enhanced-question-display"
import ProgressHUD from "./progress-hud"
import ParticleSystem from "./particle-system"
import SkillTree from "./skill-tree"
import AchievementNotification from "./achievement-notification"
import { useState, useEffect } from "react"
import CourseSelection from "./course-selection"
import AddictionEnhancer from "./addiction-enhancer"
import PersonalizedWelcome from "./personalized-welcome"

export default function GameEngine() {
  const { state, dispatch } = useGame()
  const { playSound } = useAudio()
  const [showSkillTree, setShowSkillTree] = useState(false)
  const [particles, setParticles] = useState<any[]>([])

  // Achievement checking
  useEffect(() => {
    const checkAchievements = () => {
      if (state.streak === 5 && !state.achievements.includes("streak_5")) {
        dispatch({ type: "UNLOCK_ACHIEVEMENT", payload: "streak_5" })
        playSound("achievement", 1.5)
      }

      if (state.correctAnswers === 10 && !state.achievements.includes("answers_10")) {
        dispatch({ type: "UNLOCK_ACHIEVEMENT", payload: "answers_10" })
        playSound("achievement", 1.5)
      }

      if (state.xp >= 1000 && !state.achievements.includes("xp_1000")) {
        dispatch({ type: "UNLOCK_ACHIEVEMENT", payload: "xp_1000" })
        playSound("achievement", 1.5)
      }
    }

    checkAchievements()
  }, [state.streak, state.correctAnswers, state.xp, state.achievements, dispatch, playSound])

  // Particle effects for correct answers
  useEffect(() => {
    if (state.lastAnswer === true) {
      const newParticles = Array.from({ length: state.geniusMode ? 20 : 10 }, (_, i) => ({
        id: Date.now() + i,
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        life: 1,
        color: state.geniusMode ? "#ffd700" : "#00ff88",
      }))

      setParticles((prev) => [...prev, ...newParticles])

      setTimeout(() => {
        setParticles((prev) => prev.filter((p) => !newParticles.includes(p)))
      }, 2000)
    }
  }, [state.lastAnswer, state.geniusMode])

  if (!state.selectedCourse) {
    return <CourseSelection />
  }

  if (!state.currentQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-2xl animate-pulse">Initializing Mind Forge...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-blue-500 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Personalized Welcome Message */}
      <PersonalizedWelcome />

      {/* Genius Mode Overlay */}
      {state.geniusMode && (
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 animate-pulse pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-yellow-300/10 to-transparent animate-spin-slow"></div>
        </div>
      )}

      {/* Main Game Interface */}
      <div className="relative z-10 min-h-screen flex flex-col">
        <ProgressHUD />

        <div className="flex-1 flex items-center justify-center p-4">
          {showSkillTree ? <SkillTree onClose={() => setShowSkillTree(false)} /> : <EnhancedQuestionDisplay />}
        </div>

        {/* Bottom Controls */}
        <div className="p-4 flex justify-center space-x-4">
          <button
            onClick={() => setShowSkillTree(!showSkillTree)}
            className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-semibold transition-all duration-200 transform hover:scale-105"
          >
            {showSkillTree ? "Back to Game" : "Skill Tree"}
          </button>
        </div>
      </div>

      {/* Particle System */}
      <ParticleSystem particles={particles} />

      {/* Achievement Notifications */}
      <AchievementNotification />

      {/* Global Stats Overlay - Moved to bottom-left */}
      <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-sm rounded-lg p-3 text-white text-sm border border-purple-500/30">
        <div className="text-purple-300 text-xs mb-1">GLOBAL NETWORK</div>
        <div>Players Online: {Math.floor(Math.random() * 10000) + 5000}</div>
        <div>Your Rank: #{Math.floor(Math.random() * 100) + 1}</div>
        <div className="text-green-400 text-xs mt-1">+{Math.floor(Math.random() * 50)} joined</div>
      </div>

      {/* Momentum Indicator */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
        <div className="w-2 h-32 bg-gray-700 rounded-full overflow-hidden">
          <div
            className="w-full bg-gradient-to-t from-red-500 via-yellow-500 to-green-500 transition-all duration-500 rounded-full"
            style={{ height: `${(state.momentum / 2) * 100}%` }}
          ></div>
        </div>
        <div className="text-white text-xs mt-2 text-center">Flow</div>
      </div>

      {/* Addiction Enhancement System */}
      <AddictionEnhancer />
    </div>
  )
}
