"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"

interface User {
  id: string
  name: string
  email: string
  picture: string
  studyStreak: number
  totalXP: number
  lastActive: number
  friends: string[]
  achievements: string[]
  notificationPreferences: {
    dailyReminders: boolean
    streakWarnings: boolean
    socialUpdates: boolean
    achievements: boolean
    challenges: boolean
  }
}

interface AuthContextType {
  user: User | null
  signIn: () => Promise<void>
  signOut: () => void
  updateUser: (updates: Partial<User>) => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load user from localStorage on mount
    const savedUser = localStorage.getItem("mindforge-user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (e) {
        console.error("Failed to load user:", e)
      }
    }
    setIsLoading(false)
  }, [])

  const signIn = async () => {
    try {
      // In a real implementation, this would use Google OAuth
      // For demo purposes, we'll simulate the sign-in
      const mockUser: User = {
        id: "user_" + Date.now(),
        name: "Demo User",
        email: "demo@mindforge.com",
        picture: "/placeholder.svg?height=40&width=40",
        studyStreak: Math.floor(Math.random() * 30) + 1,
        totalXP: Math.floor(Math.random() * 10000) + 1000,
        lastActive: Date.now(),
        friends: [],
        achievements: [],
        notificationPreferences: {
          dailyReminders: true,
          streakWarnings: true,
          socialUpdates: true,
          achievements: true,
          challenges: true,
        },
      }

      setUser(mockUser)
      localStorage.setItem("mindforge-user", JSON.stringify(mockUser))

      // Request notification permission after sign-in
      if ("Notification" in window && Notification.permission === "default") {
        await Notification.requestPermission()
      }
    } catch (error) {
      console.error("Sign-in failed:", error)
    }
  }

  const signOut = () => {
    setUser(null)
    localStorage.removeItem("mindforge-user")
  }

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates }
      setUser(updatedUser)
      localStorage.setItem("mindforge-user", JSON.stringify(updatedUser))
    }
  }

  return (
    <AuthContext.Provider value={{ user, signIn, signOut, updateUser, isLoading }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
