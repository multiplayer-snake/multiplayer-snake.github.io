"use client"

import { useGame } from "@/contexts/game-context"
import { useAudio } from "@/contexts/audio-context"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export default function EnhancedQuestionDisplay() {
  const { state, dispatch } = useGame()
  const { playSound } = useAudio()
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeBonus, setTimeBonus] = useState(0)
  const [showMotivation, setShowMotivation] = useState(false)
  const [rivalScore, setRivalScore] = useState(0)

  const question = state.currentQuestion

  // Enhanced addiction mechanics
  useEffect(() => {
    // Simulate rival progress for competitive pressure
    const rivalInterval = setInterval(() => {
      setRivalScore((prev) => prev + Math.random() * 2)
    }, 3000)

    // Show motivational messages
    const motivationInterval = setInterval(() => {
      if (Math.random() < 0.3) {
        setShowMotivation(true)
        setTimeout(() => setShowMotivation(false), 3000)
      }
    }, 10000)

    return () => {
      clearInterval(rivalInterval)
      clearInterval(motivationInterval)
    }
  }, [])

  // Dopamine-triggering sound cascades
  const playSuccessCascade = (intensity: number) => {
    playSound("correct", intensity)
    setTimeout(() => playSound("bonus", intensity * 0.8), 150)
    setTimeout(() => playSound("achievement", intensity * 0.6), 300)

    if (state.streak >= 5) {
      setTimeout(() => playSound("genius", intensity * 1.2), 450)
    }
  }

  const handleAnswer = (answerIndex: number) => {
    if (state.isAnswering || showResult) return

    setSelectedAnswer(answerIndex)
    setShowResult(true)

    const isCorrect = answerIndex === question.correct
    const intensity = state.geniusMode ? 2 : 1

    if (isCorrect) {
      playSuccessCascade(intensity)
      dispatch({ type: "INCREASE_DOPAMINE", payload: 10 + state.streak })
    } else {
      playSound("incorrect", 0.5)
      dispatch({ type: "INCREASE_DOPAMINE", payload: -5 })
    }

    dispatch({
      type: "ANSWER_QUESTION",
      payload: { answerIndex, timeBonus },
    })

    // Auto-advance with addictive delay
    setTimeout(
      () => {
        setShowResult(false)
        setSelectedAnswer(null)
        dispatch({ type: "NEXT_QUESTION" })
      },
      isCorrect ? 1500 : 2500,
    ) // Shorter delay for correct answers = more addictive
  }

  const getButtonClass = (index: number) => {
    let baseClass =
      "w-full p-4 text-left rounded-lg font-medium transition-all duration-200 transform hover:scale-105 relative overflow-hidden "

    if (showResult) {
      if (index === question.correct) {
        baseClass +=
          "bg-gradient-to-r from-green-500 to-emerald-500 text-white animate-pulse shadow-lg shadow-green-500/50 "
      } else if (index === selectedAnswer && index !== question.correct) {
        baseClass += "bg-gradient-to-r from-red-500 to-rose-500 text-white shadow-lg shadow-red-500/50 "
      } else {
        baseClass += "bg-gray-600 text-gray-300 "
      }
    } else {
      baseClass += state.geniusMode
        ? "bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 hover:from-yellow-500 hover:via-orange-500 hover:to-red-500 text-white shadow-lg shadow-yellow-500/30 "
        : "bg-gradient-to-r from-gray-700 to-gray-600 hover:from-purple-600 hover:to-blue-600 text-white hover:shadow-lg hover:shadow-purple-500/30 "
    }

    return baseClass
  }

  if (!question) return null

  const motivationalMessages = [
    "🔥 You're on fire! Keep going!",
    "🧠 Your brain is getting stronger!",
    "⚡ Lightning fast thinking!",
    "🎯 Perfect accuracy streak!",
    "🚀 Reaching new heights!",
    "💎 Knowledge crystallizing!",
  ]

  return (
    <div className="relative">
      <Card className="w-full max-w-4xl mx-auto bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 relative overflow-hidden">
        {/* Enhanced Background Effects */}
        {state.geniusMode && (
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 via-orange-400/10 to-red-400/10 animate-pulse"></div>
        )}

        {/* Competitive Pressure Indicator */}
        <div className="absolute top-4 right-4 bg-red-600/20 backdrop-blur-sm rounded-lg p-2 text-xs">
          <div className="text-red-400 font-bold">🏆 Rival Progress</div>
          <div className="text-white">{rivalScore.toFixed(0)} points</div>
          <div className="text-yellow-400">{rivalScore > state.xp ? "Behind!" : "Leading!"}</div>
        </div>

        {/* Question Header with Enhanced Info */}
        <div className="mb-6 relative z-10">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-4">
              <span className="text-purple-300 font-semibold">
                {question.category} • Question {state.questionIndex + 1}
              </span>
              <Badge className="bg-blue-600 animate-pulse">Dopamine: {state.dopamineLevel}%</Badge>
            </div>

            <div className="flex items-center space-x-4">
              {state.geniusMode && (
                <div className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-3 py-1 rounded-full text-sm font-bold animate-bounce">
                  🧠 GENIUS MODE {state.geniusModeTimer}s
                </div>
              )}

              <div className="text-white font-mono text-lg bg-black/50 px-3 py-1 rounded">{state.timeLeft}s</div>
            </div>
          </div>

          {/* Enhanced Timer Progress */}
          <div className="relative">
            <Progress value={(state.timeLeft / 30) * 100} className="h-3 mb-4" />
            {state.timeLeft <= 10 && <div className="absolute inset-0 bg-red-500/20 animate-pulse rounded"></div>}
          </div>

          {/* Story Fragment with Enhanced Presentation */}
          <div className="text-purple-200 text-sm italic mb-4 opacity-80 bg-purple-900/20 p-3 rounded-lg border-l-4 border-purple-500">
            ✨ {question.story}
          </div>
        </div>

        {/* Enhanced Question Display */}
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 leading-relaxed relative">
          {question.question}
          {state.streak >= 3 && <div className="absolute -top-2 -right-2 text-yellow-400 animate-bounce">🔥</div>}
        </h2>

        {/* Answer Options with Enhanced Effects */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {question.options.map((option: string, index: number) => (
            <Button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={showResult}
              className={getButtonClass(index)}
              variant="ghost"
            >
              {/* Animated Background for Hover */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/0 to-blue-600/0 hover:from-purple-600/20 hover:to-blue-600/20 transition-all duration-300"></div>

              <div className="relative z-10 flex items-center">
                <span className="mr-3 font-bold text-lg bg-white/20 w-8 h-8 rounded-full flex items-center justify-center">
                  {String.fromCharCode(65 + index)}
                </span>
                {option}
              </div>
            </Button>
          ))}
        </div>

        {/* Enhanced Bonus Indicators */}
        <div className="flex justify-between items-center text-sm mb-4">
          <div className="flex space-x-4">
            {state.bonusMultiplier > 1 && (
              <div className="text-yellow-400 font-bold animate-bounce bg-yellow-400/20 px-3 py-1 rounded-full">
                💰 {state.bonusMultiplier.toFixed(1)}x BONUS!
              </div>
            )}
            {timeBonus > 0 && (
              <div className="text-blue-400 bg-blue-400/20 px-3 py-1 rounded-full">
                ⚡ Speed Bonus: +{Math.floor(timeBonus * 100)}%
              </div>
            )}
            {state.streak >= 5 && (
              <div className="text-red-400 font-bold animate-pulse bg-red-400/20 px-3 py-1 rounded-full">
                🔥 ON FIRE x{state.streak}
              </div>
            )}
          </div>

          <div className="text-purple-300 bg-purple-900/30 px-3 py-1 rounded-full">
            Streak: {state.streak} • Flow: {state.momentum.toFixed(1)}
          </div>
        </div>

        {/* Enhanced Result Feedback */}
        {showResult && (
          <div className="mt-6 p-6 rounded-lg bg-black/50 text-center border-2 border-purple-500/50">
            {selectedAnswer === question.correct ? (
              <div className="space-y-2">
                <div className="text-green-400 font-bold text-2xl animate-bounce">🎉 CORRECT!</div>
                <div className="text-yellow-400 text-lg">
                  +{Math.floor(100 * state.bonusMultiplier * (1 + timeBonus))} XP
                </div>
                <div className="text-purple-300 text-sm">🧠 Neural pathway strengthened!</div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-red-400 font-bold text-xl">❌ Not quite right</div>
                <div className="text-white">
                  The answer was{" "}
                  <span className="font-bold text-green-400">{String.fromCharCode(65 + question.correct)}</span>
                </div>
                <div className="text-purple-300 text-sm">
                  💎 Knowledge gem fractured - repair it in your skill tree!
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Motivational Overlay */}
      {showMotivation && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 animate-bounce">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-6 py-3 rounded-full font-bold text-lg shadow-2xl">
            {motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)]}
          </div>
        </div>
      )}

      {/* Social Pressure Notifications */}
      {Math.random() < 0.1 && (
        <div className="fixed bottom-20 right-4 bg-blue-600/90 backdrop-blur-sm text-white p-3 rounded-lg text-sm animate-slide-in-right">
          👥 {Math.floor(Math.random() * 50) + 10} students just joined your subject!
        </div>
      )}
    </div>
  )
}
