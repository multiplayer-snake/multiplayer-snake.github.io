"use client"

import { useGame } from "@/contexts/game-context"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"

const COURSES = {
  GCSE: {
    name: "GCSE",
    description: "General Certificate of Secondary Education",
    color: "from-blue-600 to-purple-600",
    subjects: [
      { id: "gcse_maths", name: "Mathematics", icon: "🔢", difficulty: "Core", questions: 150 },
      { id: "gcse_english", name: "English Language", icon: "📝", difficulty: "Core", questions: 120 },
      { id: "gcse_science", name: "Combined Science", icon: "🧪", difficulty: "Core", questions: 200 },
      { id: "gcse_history", name: "History", icon: "🏛️", difficulty: "Standard", questions: 100 },
      { id: "gcse_geography", name: "Geography", icon: "🌍", difficulty: "Standard", questions: 90 },
      { id: "gcse_french", name: "French", icon: "🇫🇷", difficulty: "Standard", questions: 80 },
      { id: "gcse_art", name: "Art & Design", icon: "🎨", difficulty: "Creative", questions: 60 },
      { id: "gcse_pe", name: "Physical Education", icon: "⚽", difficulty: "Practical", questions: 70 },
    ],
  },
  "A-Level": {
    name: "A-Level",
    description: "Advanced Level Qualifications",
    color: "from-purple-600 to-pink-600",
    subjects: [
      { id: "alevel_maths", name: "Mathematics", icon: "📐", difficulty: "Advanced", questions: 200 },
      { id: "alevel_physics", name: "Physics", icon: "⚛️", difficulty: "Advanced", questions: 180 },
      { id: "alevel_chemistry", name: "Chemistry", icon: "🧬", difficulty: "Advanced", questions: 170 },
      { id: "alevel_biology", name: "Biology", icon: "🦠", difficulty: "Advanced", questions: 160 },
      { id: "alevel_english", name: "English Literature", icon: "📚", difficulty: "Advanced", questions: 140 },
      { id: "alevel_history", name: "History", icon: "📜", difficulty: "Advanced", questions: 130 },
    ],
  },
  University: {
    name: "University",
    description: "Higher Education Preparation",
    color: "from-green-600 to-teal-600",
    subjects: [
      { id: "uni_calculus", name: "Calculus", icon: "∫", difficulty: "Expert", questions: 250 },
      { id: "uni_programming", name: "Computer Science", icon: "💻", difficulty: "Expert", questions: 300 },
      { id: "uni_psychology", name: "Psychology", icon: "🧠", difficulty: "Expert", questions: 200 },
      { id: "uni_economics", name: "Economics", icon: "📈", difficulty: "Expert", questions: 180 },
      { id: "uni_philosophy", name: "Philosophy", icon: "🤔", difficulty: "Expert", questions: 150 },
    ],
  },
  "General Knowledge": {
    name: "General Knowledge",
    description: "Expand your horizons",
    color: "from-orange-600 to-red-600",
    subjects: [
      { id: "gk_world", name: "World Facts", icon: "🌎", difficulty: "Mixed", questions: 500 },
      { id: "gk_science", name: "Science Trivia", icon: "🔬", difficulty: "Mixed", questions: 400 },
      { id: "gk_history", name: "Historical Events", icon: "⏳", difficulty: "Mixed", questions: 350 },
      { id: "gk_culture", name: "Arts & Culture", icon: "🎭", difficulty: "Mixed", questions: 300 },
      { id: "gk_sports", name: "Sports & Games", icon: "🏆", difficulty: "Mixed", questions: 250 },
    ],
  },
}

export default function CourseSelection() {
  const { dispatch } = useGame()
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const [hoveredSubject, setHoveredSubject] = useState<string | null>(null)

  const selectSubject = (courseId: string, subjectId: string) => {
    dispatch({
      type: "SELECT_COURSE",
      payload: {
        course: courseId,
        subject: subjectId,
        subjectData: COURSES[courseId as keyof typeof COURSES].subjects.find((s) => s.id === subjectId),
      },
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full blur-3xl opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-indigo-500 rounded-full blur-3xl opacity-10 animate-spin-slow"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Mind Forge Academy
          </h1>
          <p className="text-xl text-purple-200 mb-2">Choose Your Learning Path</p>
          <div className="flex justify-center space-x-4 text-sm text-purple-300">
            <span>🧠 Neural Enhancement</span>
            <span>⚡ Instant Feedback</span>
            <span>🏆 Global Competition</span>
            <span>🎯 Adaptive Learning</span>
          </div>
        </div>

        {!selectedCourse ? (
          /* Course Selection */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(COURSES).map(([courseId, course]) => (
              <Card
                key={courseId}
                className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-6 cursor-pointer transform transition-all duration-300 hover:scale-105 hover:bg-black/60 group"
                onClick={() => setSelectedCourse(courseId)}
              >
                <div
                  className={`w-full h-32 bg-gradient-to-br ${course.color} rounded-lg mb-4 flex items-center justify-center text-4xl text-white font-bold group-hover:animate-pulse`}
                >
                  {course.name}
                </div>

                <h3 className="text-xl font-bold text-white mb-2">{course.name}</h3>
                <p className="text-purple-200 text-sm mb-4">{course.description}</p>

                <div className="flex justify-between items-center">
                  <Badge className="bg-purple-600">{course.subjects.length} Subjects</Badge>
                  <div className="text-green-400 text-sm font-semibold">
                    {course.subjects.reduce((total, subject) => total + subject.questions, 0)} Questions
                  </div>
                </div>

                {/* Addictive Preview */}
                <div className="mt-3 text-xs text-yellow-400 opacity-80">
                  🔥 {Math.floor(Math.random() * 1000) + 500} students mastering this today
                </div>
              </Card>
            ))}
          </div>
        ) : (
          /* Subject Selection */
          <div>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-4xl font-bold text-white mb-2">
                  {COURSES[selectedCourse as keyof typeof COURSES].name} Subjects
                </h2>
                <p className="text-purple-200">{COURSES[selectedCourse as keyof typeof COURSES].description}</p>
              </div>
              <Button
                onClick={() => setSelectedCourse(null)}
                variant="outline"
                className="border-purple-500 text-purple-300 hover:bg-purple-600 hover:text-white"
              >
                ← Back to Courses
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {COURSES[selectedCourse as keyof typeof COURSES].subjects.map((subject) => (
                <Card
                  key={subject.id}
                  className="bg-black/40 backdrop-blur-sm border-purple-500/30 p-6 cursor-pointer transform transition-all duration-300 hover:scale-105 hover:bg-black/60 group relative overflow-hidden"
                  onClick={() => selectSubject(selectedCourse, subject.id)}
                  onMouseEnter={() => setHoveredSubject(subject.id)}
                  onMouseLeave={() => setHoveredSubject(null)}
                >
                  {/* Animated Background */}
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  <div className="relative z-10">
                    <div className="text-4xl mb-4 group-hover:animate-bounce">{subject.icon}</div>

                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                      {subject.name}
                    </h3>

                    <div className="flex justify-between items-center mb-4">
                      <Badge
                        className={`${
                          subject.difficulty === "Core"
                            ? "bg-green-600"
                            : subject.difficulty === "Standard"
                              ? "bg-blue-600"
                              : subject.difficulty === "Advanced"
                                ? "bg-purple-600"
                                : subject.difficulty === "Expert"
                                  ? "bg-red-600"
                                  : "bg-orange-600"
                        }`}
                      >
                        {subject.difficulty}
                      </Badge>
                      <div className="text-yellow-400 font-semibold">{subject.questions} Q's</div>
                    </div>

                    {/* Addictive Elements */}
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between text-purple-300">
                        <span>Completion Rate:</span>
                        <span className="text-green-400">{Math.floor(Math.random() * 40) + 60}%</span>
                      </div>

                      <div className="flex justify-between text-purple-300">
                        <span>Your Best Streak:</span>
                        <span className="text-yellow-400">{Math.floor(Math.random() * 20) + 5}</span>
                      </div>

                      <div className="flex justify-between text-purple-300">
                        <span>Global Rank:</span>
                        <span className="text-blue-400">#{Math.floor(Math.random() * 1000) + 100}</span>
                      </div>

                      {hoveredSubject === subject.id && (
                        <div className="mt-3 p-2 bg-yellow-400/20 rounded text-yellow-300 animate-pulse">
                          🎯 Ready to dominate this subject?
                        </div>
                      )}
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-4">
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full transition-all duration-1000 group-hover:animate-pulse"
                          style={{ width: `${Math.floor(Math.random() * 80) + 10}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-purple-300 mt-1">
                        {Math.floor(Math.random() * 50) + 10}% mastered
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Daily Challenge Teaser */}
            <Card className="mt-8 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border-yellow-500/50 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-yellow-400 mb-2">🔥 Daily Challenge Available!</h3>
                  <p className="text-yellow-200">Complete today's mixed challenge for 3x XP bonus</p>
                  <div className="text-sm text-yellow-300 mt-1">
                    ⏰ Resets in {Math.floor(Math.random() * 12) + 1} hours • 🏆 {Math.floor(Math.random() * 500) + 200}{" "}
                    players completed
                  </div>
                </div>
                <Button
                  className="bg-yellow-600 hover:bg-yellow-500 text-black font-bold px-8 py-3 animate-pulse"
                  onClick={() => selectSubject("daily", "daily_challenge")}
                >
                  Accept Challenge
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* Bottom Stats */}
        <div className="mt-12 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-400">{(Math.random() * 50000 + 10000).toFixed(0)}</div>
              <div className="text-purple-300 text-sm">Questions Answered Today</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-400">{(Math.random() * 5000 + 1000).toFixed(0)}</div>
              <div className="text-purple-300 text-sm">Active Learners</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-400">{Math.floor(Math.random() * 100) + 50}</div>
              <div className="text-purple-300 text-sm">Countries Represented</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-400">98.{Math.floor(Math.random() * 9) + 1}%</div>
              <div className="text-purple-300 text-sm">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
