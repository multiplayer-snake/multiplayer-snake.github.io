"use client"

import { useGame } from "@/contexts/game-context"
import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"

const ACHIEVEMENT_DATA = {
  streak_5: {
    title: "Knowledge Streak",
    description: "Answer 5 questions correctly in a row",
    icon: "🔥",
  },
  answers_10: {
    title: "Dedicated Learner",
    description: "Answer 10 questions correctly",
    icon: "📚",
  },
  xp_1000: {
    title: "Experience Master",
    description: "Earn 1000 XP",
    icon: "⭐",
  },
}

export default function AchievementNotification() {
  const { state } = useGame()
  const [visibleAchievements, setVisibleAchievements] = useState<string[]>([])
  const [lastAchievementCount, setLastAchievementCount] = useState(0)

  useEffect(() => {
    if (state.achievements.length > lastAchievementCount) {
      const newAchievements = state.achievements.slice(lastAchievementCount)
      setVisibleAchievements((prev) => [...prev, ...newAchievements])
      setLastAchievementCount(state.achievements.length)

      // Auto-hide after 5 seconds
      setTimeout(() => {
        setVisibleAchievements((prev) => prev.filter((a) => !newAchievements.includes(a)))
      }, 5000)
    }
  }, [state.achievements, lastAchievementCount])

  if (visibleAchievements.length === 0) return null

  return (
    <div className="fixed top-20 right-4 z-50 space-y-2">
      {visibleAchievements.map((achievementId) => {
        const achievement = ACHIEVEMENT_DATA[achievementId as keyof typeof ACHIEVEMENT_DATA]
        if (!achievement) return null

        return (
          <Card
            key={achievementId}
            className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black p-4 animate-slide-in-right shadow-2xl border-2 border-yellow-300"
          >
            <div className="flex items-center space-x-3">
              <div className="text-2xl">{achievement.icon}</div>
              <div>
                <div className="font-bold text-lg">Achievement Unlocked!</div>
                <div className="font-semibold">{achievement.title}</div>
                <div className="text-sm opacity-80">{achievement.description}</div>
              </div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
