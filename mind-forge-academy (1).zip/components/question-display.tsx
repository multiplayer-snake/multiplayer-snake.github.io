"use client"

import { useGame } from "@/contexts/game-context"
import { useAudio } from "@/contexts/audio-context"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function QuestionDisplay() {
  const { state, dispatch } = useGame()
  const { playSound } = useAudio()
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [timeBonus, setTimeBonus] = useState(0)

  const question = state.currentQuestion

  useEffect(() => {
    if (state.timeLeft <= 0 && !showResult) {
      handleAnswer(-1) // Time's up
    }
  }, [state.timeLeft, showResult])

  useEffect(() => {
    // Calculate time bonus
    const bonus = Math.max(0, (state.timeLeft - 10) / 20)
    setTimeBonus(bonus)
  }, [state.timeLeft])

  const handleAnswer = (answerIndex: number) => {
    if (state.isAnswering || showResult) return

    setSelectedAnswer(answerIndex)
    setShowResult(true)

    const isCorrect = answerIndex === question.correct
    const intensity = state.geniusMode ? 2 : 1

    if (isCorrect) {
      playSound("correct", intensity)
      if (state.bonusMultiplier > 1) {
        setTimeout(() => playSound("bonus", intensity), 200)
      }
    } else {
      playSound("incorrect", 0.5)
    }

    dispatch({
      type: "ANSWER_QUESTION",
      payload: { answerIndex, timeBonus },
    })

    // Auto-advance after showing result
    setTimeout(() => {
      setShowResult(false)
      setSelectedAnswer(null)
      dispatch({ type: "NEXT_QUESTION" })
    }, 2000)
  }

  const getButtonClass = (index: number) => {
    let baseClass = "w-full p-4 text-left rounded-lg font-medium transition-all duration-200 transform hover:scale-105 "

    if (showResult) {
      if (index === question.correct) {
        baseClass += "bg-green-500 text-white animate-pulse "
      } else if (index === selectedAnswer && index !== question.correct) {
        baseClass += "bg-red-500 text-white "
      } else {
        baseClass += "bg-gray-600 text-gray-300 "
      }
    } else {
      baseClass += state.geniusMode
        ? "bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white "
        : "bg-gray-700 hover:bg-gray-600 text-white "
    }

    return baseClass
  }

  if (!question) return null

  return (
    <Card className="w-full max-w-4xl mx-auto bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
      {/* Question Header */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <span className="text-purple-300 font-semibold">
            {question.category} • Question {state.questionIndex + 1}
          </span>
          <div className="flex items-center space-x-4">
            {state.geniusMode && (
              <div className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-3 py-1 rounded-full text-sm font-bold animate-pulse">
                GENIUS MODE {state.geniusModeTimer}s
              </div>
            )}
            <div className="text-white font-mono text-lg">{state.timeLeft}s</div>
          </div>
        </div>

        {/* Timer Progress */}
        <Progress value={(state.timeLeft / 30) * 100} className="h-2 mb-4" />

        {/* Story Fragment */}
        <div className="text-purple-200 text-sm italic mb-4 opacity-80">{question.story}</div>
      </div>

      {/* Question */}
      <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 leading-relaxed">{question.question}</h2>

      {/* Answer Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {question.options.map((option: string, index: number) => (
          <Button
            key={index}
            onClick={() => handleAnswer(index)}
            disabled={showResult}
            className={getButtonClass(index)}
            variant="ghost"
          >
            <span className="mr-3 font-bold">{String.fromCharCode(65 + index)}.</span>
            {option}
          </Button>
        ))}
      </div>

      {/* Bonus Indicators */}
      <div className="flex justify-between items-center text-sm">
        <div className="flex space-x-4">
          {state.bonusMultiplier > 1 && (
            <div className="text-yellow-400 font-bold animate-bounce">{state.bonusMultiplier.toFixed(1)}x BONUS!</div>
          )}
          {timeBonus > 0 && <div className="text-blue-400">Speed Bonus: +{Math.floor(timeBonus * 100)}%</div>}
        </div>

        <div className="text-purple-300">
          Streak: {state.streak} • Momentum: {state.momentum.toFixed(1)}
        </div>
      </div>

      {/* Result Feedback */}
      {showResult && (
        <div className="mt-6 p-4 rounded-lg bg-black/50 text-center">
          {selectedAnswer === question.correct ? (
            <div className="text-green-400 font-bold text-lg">
              🎉 Correct! +{Math.floor(100 * state.bonusMultiplier * (1 + timeBonus))} XP
            </div>
          ) : (
            <div className="text-red-400 font-bold text-lg">
              ❌ Incorrect. The answer was {String.fromCharCode(65 + question.correct)}.
            </div>
          )}
        </div>
      )}
    </Card>
  )
}
