"use client"

import type React from "react"
import { useState } from "react"
import { supabase, signInWithGoogle } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"
import PasswordReset from "./password-reset"

export default function AuthForm() {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [loading, setLoading] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | "info">("info")
  const [emailSent, setEmailSent] = useState(false)
  const [acceptedTerms, setAcceptedTerms] = useState(false)
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false)
  const [otpCode, setOtpCode] = useState("")
  const [isVerifyingOTP, setIsVerifyingOTP] = useState(false)
  const [showPasswordReset, setShowPasswordReset] = useState(false)

  // Secretly assign A/B test group and psychological profile
  const assignABTestGroup = () => {
    const groups = ["control", "gamified", "social", "achievement", "curiosity"]
    return groups[Math.floor(Math.random() * groups.length)]
  }

  const generatePsychologicalProfile = () => {
    return {
      motivationType: Math.random() > 0.5 ? "intrinsic" : "extrinsic",
      competitiveLevel: Math.floor(Math.random() * 10) + 1,
      socialInfluence: Math.floor(Math.random() * 10) + 1,
      achievementOriented: Math.random() > 0.3,
      curiosityDriven: Math.random() > 0.4,
      lossAversion: Math.floor(Math.random() * 10) + 1,
      instantGratification: Math.floor(Math.random() * 10) + 1,
      streakMotivation: Math.random() > 0.6,
      socialProofSensitive: Math.random() > 0.5,
      challengeSeeker: Math.random() > 0.4,
    }
  }

  const showMessage = (text: string, type: "success" | "error" | "info" = "info") => {
    setMessage(text)
    setMessageType(type)
    setTimeout(() => setMessage(""), 5000)
  }

  const validateForm = () => {
    if (isSignUp) {
      if (!fullName.trim()) {
        showMessage("Please enter your full name", "error")
        return false
      }
      if (fullName.trim().length < 2) {
        showMessage("Name must be at least 2 characters long", "error")
        return false
      }
      if (!acceptedTerms) {
        showMessage("Please accept the Terms & Conditions", "error")
        return false
      }
      if (!acceptedPrivacy) {
        showMessage("Please accept the Privacy Policy", "error")
        return false
      }
    }

    if (!email.trim()) {
      showMessage("Please enter your email address", "error")
      return false
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      showMessage("Please enter a valid email address", "error")
      return false
    }

    if (!password) {
      showMessage("Please enter your password", "error")
      return false
    }

    if (isSignUp && password.length < 6) {
      showMessage("Password must be at least 6 characters long", "error")
      return false
    }

    return true
  }

  const handleGoogleSignIn = async () => {
    if (isSignUp && (!acceptedTerms || !acceptedPrivacy)) {
      showMessage("Please accept the Terms & Conditions and Privacy Policy", "error")
      return
    }

    setGoogleLoading(true)
    setMessage("")

    try {
      await signInWithGoogle()
      // The redirect will be handled by the OAuth flow
    } catch (error: any) {
      console.error("Google sign-in error:", error)
      showMessage(error.message || "Google sign-in failed. Please try again.", "error")
      setGoogleLoading(false)
    }
  }

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setLoading(true)
    setMessage("")

    try {
      if (isSignUp) {
        // For sign up, we'll use OTP-based email verification
        const { data, error } = await supabase.auth.signInWithOtp({
          email: email.trim(),
          options: {
            shouldCreateUser: true,
            data: {
              full_name: fullName.trim(),
              first_name: fullName.trim().split(" ")[0],
            },
          },
        })

        if (error) {
          console.error("Sign up error:", error)
          if (error.message.includes("already registered")) {
            showMessage("This email is already registered. Please sign in instead.", "error")
            setIsSignUp(false)
          } else {
            showMessage(error.message || "Sign up failed. Please try again.", "error")
          }
          return
        }

        setEmailSent(true)
        showMessage("Please check your email for a 6-digit verification code!", "success")
      } else {
        // Sign in existing user
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        })

        if (error) {
          console.error("Sign in error:", error)

          if (error.message.includes("Invalid login credentials")) {
            showMessage("Invalid email or password. Please check your credentials.", "error")
          } else if (error.message.includes("Email not confirmed")) {
            showMessage("Please verify your email address. We'll send you a new verification code.", "error")
            // Send OTP for unverified users
            await sendOTPCode()
          } else {
            showMessage(error.message || "Sign in failed. Please try again.", "error")
          }
          return
        }

        if (data.user) {
          // Handle successful sign in
          try {
            const { data: existingProfile } = await supabase
              .from("users")
              .select("id, first_name")
              .eq("id", data.user.id)
              .single()

            if (existingProfile) {
              await supabase.from("users").update({ last_active: new Date().toISOString() }).eq("id", data.user.id)
              showMessage(`Welcome back, ${existingProfile.first_name || "genius"}! 🧠`, "success")
            } else {
              // Create missing profile
              const firstName =
                data.user.user_metadata?.first_name || data.user.user_metadata?.full_name?.split(" ")[0] || "genius"

              await supabase.from("users").insert({
                id: data.user.id,
                email: data.user.email!,
                full_name: data.user.user_metadata?.full_name || fullName || "Anonymous User",
                first_name: firstName,
                ab_test_group: assignABTestGroup(),
                psychological_profile: generatePsychologicalProfile(),
                learning_style: ["visual", "auditory", "kinesthetic"][Math.floor(Math.random() * 3)],
                notification_preferences: {
                  dailyReminders: true,
                  streakWarnings: true,
                  socialUpdates: true,
                  achievements: true,
                  challenges: true,
                },
              })

              showMessage(`Welcome, ${firstName}! 🧠`, "success")
            }
          } catch (profileError) {
            console.error("Profile update error:", profileError)
            showMessage("Signed in successfully!", "success")
          }
        }
      }
    } catch (error: any) {
      console.error("Unexpected auth error:", error)
      showMessage("An unexpected error occurred. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  const sendOTPCode = async () => {
    if (!email.trim()) {
      showMessage("Please enter your email address", "error")
      return
    }

    try {
      const { data, error } = await supabase.auth.signInWithOtp({
        email: email.trim(),
        options: {
          shouldCreateUser: false, // Don't create user for resend
        },
      })

      if (error) {
        console.error("OTP send error:", error)
        showMessage(error.message || "Failed to send verification code", "error")
      } else {
        setEmailSent(true)
        showMessage("Verification code sent! Check your email.", "success")
      }
    } catch (error: any) {
      console.error("OTP send error:", error)
      showMessage("Failed to send verification code. Please try again.", "error")
    }
  }

  const handleOTPVerification = async (e: React.FormEvent) => {
    e.preventDefault()

    if (otpCode.length !== 6) {
      showMessage("Please enter a valid 6-digit code", "error")
      return
    }

    setIsVerifyingOTP(true)
    setMessage("")

    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email: email.trim(),
        token: otpCode,
        type: "email",
      })

      if (error) {
        console.error("OTP verification error:", error)

        if (error.message.includes("expired")) {
          showMessage("Verification code has expired. Please request a new one.", "error")
        } else if (error.message.includes("invalid") || error.message.includes("Token")) {
          showMessage("Invalid verification code. Please check and try again.", "error")
        } else {
          showMessage(error.message || "Verification failed. Please try again.", "error")
        }
        return
      }

      if (data.user) {
        // Create user profile after successful verification
        try {
          const firstName = fullName.trim().split(" ")[0] || "genius"

          // Check if profile already exists
          const { data: existingProfile } = await supabase.from("users").select("id").eq("id", data.user.id).single()

          if (!existingProfile) {
            const { error: profileError } = await supabase.from("users").insert({
              id: data.user.id,
              email: data.user.email!,
              full_name: fullName.trim(),
              first_name: firstName,
              ab_test_group: assignABTestGroup(),
              psychological_profile: generatePsychologicalProfile(),
              learning_style: ["visual", "auditory", "kinesthetic"][Math.floor(Math.random() * 3)],
              notification_preferences: {
                dailyReminders: true,
                streakWarnings: true,
                socialUpdates: true,
                achievements: true,
                challenges: true,
              },
            })

            if (profileError && !profileError.message.includes("duplicate")) {
              console.error("Profile creation error:", profileError)
              showMessage("Account verified but profile setup failed. Please contact support.", "error")
              return
            }
          }

          showMessage(`Welcome to Mind Forge Academy, ${firstName}! 🧠🎉`, "success")
          // The user will be automatically redirected by the auth state change
        } catch (profileErr) {
          console.error("Profile creation error:", profileErr)
          showMessage("Account verified but profile setup failed. Please contact support.", "error")
        }
      }
    } catch (error: any) {
      console.error("Unexpected OTP verification error:", error)
      showMessage("An unexpected error occurred. Please try again.", "error")
    } finally {
      setIsVerifyingOTP(false)
    }
  }

  const resendVerification = async () => {
    if (!email.trim()) {
      showMessage("Please enter your email address", "error")
      return
    }

    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: email.trim(),
        options: {
          emailRedirectTo: `${window.location.origin}/auth/verify`,
        },
      })

      if (error) {
        console.error("Resend error:", error)
        showMessage(error.message || "Failed to resend verification email", "error")
      } else {
        showMessage("Verification email sent! Check your inbox.", "success")
      }
    } catch (error: any) {
      console.error("Resend error:", error)
      showMessage("Failed to resend verification email. Please try again.", "error")
    }
  }

  if (showPasswordReset) {
    return <PasswordReset onBack={() => setShowPasswordReset(false)} />
  }

  if (emailSent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="relative z-10 w-full max-w-md bg-black/40 backdrop-blur-sm border-purple-500/30 p-8 text-center">
          <div className="text-6xl mb-4">🔐</div>
          <h1 className="text-3xl font-bold text-white mb-4">Enter Verification Code</h1>
          <p className="text-purple-200 mb-6">
            We've sent a 6-digit verification code to <strong>{email}</strong>. Enter it below to verify your account.
          </p>

          <form onSubmit={handleOTPVerification} className="space-y-4">
            <div>
              <Input
                type="text"
                placeholder="Enter 6-digit code"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300 text-center text-2xl tracking-widest"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={isVerifyingOTP || otpCode.length !== 6}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3"
            >
              {isVerifyingOTP ? "Verifying..." : "Verify Code"}
            </Button>
          </form>

          {message && (
            <div
              className={`mt-4 p-3 rounded-lg text-sm border ${
                messageType === "error"
                  ? "bg-red-500/20 text-red-300 border-red-500/30"
                  : messageType === "success"
                    ? "bg-green-500/20 text-green-300 border-green-500/30"
                    : "bg-blue-500/20 text-blue-300 border-blue-500/30"
              }`}
            >
              {message}
            </div>
          )}

          <div className="mt-6 space-y-4">
            <Button
              onClick={sendOTPCode}
              variant="outline"
              className="w-full border-purple-500 text-purple-300 hover:bg-purple-600 hover:text-white bg-transparent"
            >
              Resend Code
            </Button>

            <Button
              onClick={() => {
                setEmailSent(false)
                setOtpCode("")
                setMessage("")
              }}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              Back to Sign In
            </Button>
          </div>

          <p className="text-xs text-purple-400 opacity-80 mt-4">
            Check your spam folder if you don't see the email within a few minutes
          </p>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full blur-3xl opacity-20 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-indigo-500 rounded-full blur-3xl opacity-10 animate-spin-slow"></div>
      </div>

      <Card className="relative z-10 w-full max-w-md bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🧠</div>
          <h1 className="text-4xl font-bold text-white mb-2 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Mind Forge Academy
          </h1>
          <p className="text-purple-200">{isSignUp ? "Join the learning revolution" : "Welcome back, genius"}</p>
        </div>

        {/* Social Proof - Secretly creates urgency */}
        <div className="mb-6 text-center">
          <div className="flex justify-center space-x-4 mb-2">
            <Badge className="bg-green-600 animate-pulse">{(Math.random() * 1000 + 500).toFixed(0)} studying now</Badge>
            <Badge className="bg-blue-600">{Math.floor(Math.random() * 50) + 150} countries</Badge>
          </div>
          <p className="text-sm text-purple-300">
            🔥 {Math.floor(Math.random() * 100) + 50} people joined in the last hour
          </p>
        </div>

        {/* Google Sign In Button */}
        <Button
          onClick={handleGoogleSignIn}
          disabled={googleLoading}
          className="w-full bg-white hover:bg-gray-100 text-black font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 mb-4"
        >
          <div className="flex items-center justify-center space-x-3">
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            <span>{googleLoading ? "Signing in..." : "Continue with Google"}</span>
          </div>
        </Button>

        {/* Divider */}
        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-purple-500/30"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-black/40 text-purple-300">or</span>
          </div>
        </div>

        {/* Email Auth Form */}
        <form onSubmit={handleAuth} className="space-y-4">
          {isSignUp && (
            <div>
              <Input
                type="text"
                placeholder="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
              />
            </div>
          )}

          <div>
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
            />
          </div>

          <div>
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
            />
          </div>

          {/* Terms and Privacy Checkboxes for Sign Up */}
          {isSignUp && (
            <div className="space-y-3">
              <div className="flex items-start space-x-2">
                <Checkbox id="terms" checked={acceptedTerms} onCheckedChange={setAcceptedTerms} className="mt-1" />
                <label htmlFor="terms" className="text-sm text-purple-200 leading-relaxed">
                  I agree to the{" "}
                  <Link href="/terms" className="text-purple-400 hover:text-purple-300 underline">
                    Terms & Conditions
                  </Link>
                </label>
              </div>

              <div className="flex items-start space-x-2">
                <Checkbox
                  id="privacy"
                  checked={acceptedPrivacy}
                  onCheckedChange={setAcceptedPrivacy}
                  className="mt-1"
                />
                <label htmlFor="privacy" className="text-sm text-purple-200 leading-relaxed">
                  I agree to the{" "}
                  <Link href="/privacy" className="text-purple-400 hover:text-purple-300 underline">
                    Privacy Policy
                  </Link>
                </label>
              </div>
            </div>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 transition-all duration-200 transform hover:scale-105"
          >
            {loading ? "Processing..." : isSignUp ? "Create Account" : "Sign In"}
          </Button>
        </form>

        {/* Message Display */}
        {message && (
          <div
            className={`mt-4 p-3 rounded-lg text-sm border ${
              messageType === "error"
                ? "bg-red-500/20 text-red-300 border-red-500/30"
                : messageType === "success"
                  ? "bg-green-500/20 text-green-300 border-green-500/30"
                  : "bg-blue-500/20 text-blue-300 border-blue-500/30"
            }`}
          >
            {message}
          </div>
        )}

        {/* Toggle Sign Up/Sign In */}
        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={() => {
              setIsSignUp(!isSignUp)
              setMessage("")
              setAcceptedTerms(false)
              setAcceptedPrivacy(false)
            }}
            className="text-purple-300 hover:text-purple-200 text-sm transition-colors"
          >
            {isSignUp ? "Already have an account? Sign in" : "Don't have an account? Sign up"}
          </button>
        </div>

        {!isSignUp && (
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => setShowPasswordReset(true)}
              className="text-purple-300 hover:text-purple-200 text-sm transition-colors"
            >
              Forgot your password?
            </button>
          </div>
        )}

        {/* Secretly addictive FOMO elements */}
        {isSignUp && (
          <div className="mt-6 p-4 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/50 rounded-lg">
            <div className="text-yellow-400 font-bold text-sm mb-1">🎁 EARLY ADOPTER BONUS</div>
            <div className="text-white text-sm">
              Sign up now and get <span className="font-bold text-yellow-400">1000 bonus XP</span> + exclusive beta
              features!
            </div>
            <div className="text-xs text-yellow-300 mt-1">
              ⏰ Limited time: {Math.floor(Math.random() * 100) + 50} spots remaining
            </div>
          </div>
        )}

        {/* Privacy Note */}
        <p className="text-xs text-purple-400 opacity-80 text-center mt-4">
          We use advanced AI to personalize your learning experience
        </p>
      </Card>

      {/* Floating Achievement Previews - Creates desire */}
      <div className="absolute top-20 left-10 animate-bounce delay-1000">
        <div className="bg-yellow-400/20 backdrop-blur-sm rounded-lg p-3 text-yellow-400 text-sm">🏆 Streak Master</div>
      </div>

      <div className="absolute bottom-20 right-10 animate-bounce delay-2000">
        <div className="bg-green-400/20 backdrop-blur-sm rounded-lg p-3 text-green-400 text-sm">🧠 Genius Level</div>
      </div>

      <div className="absolute top-1/3 right-20 animate-bounce delay-3000">
        <div className="bg-purple-400/20 backdrop-blur-sm rounded-lg p-3 text-purple-400 text-sm">⚡ Speed Demon</div>
      </div>
    </div>
  )
}
