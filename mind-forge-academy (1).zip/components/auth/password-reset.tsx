"use client"

import type React from "react"
import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"

interface PasswordResetProps {
  onBack: () => void
}

export default function PasswordReset({ onBack }: PasswordResetProps) {
  const [step, setStep] = useState<"email" | "otp" | "password">("email")
  const [email, setEmail] = useState("")
  const [otpCode, setOtpCode] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error" | "info">("info")

  const showMessage = (text: string, type: "success" | "error" | "info" = "info") => {
    setMessage(text)
    setMessageType(type)
    setTimeout(() => setMessage(""), 5000)
  }

  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email.trim()) {
      showMessage("Please enter your email address", "error")
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      showMessage("Please enter a valid email address", "error")
      return
    }

    setLoading(true)
    setMessage("")

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })

      if (error) {
        console.error("Password reset error:", error)
        showMessage(error.message || "Failed to send reset email", "error")
      } else {
        setStep("otp")
        showMessage("Password reset code sent! Check your email.", "success")
      }
    } catch (error: any) {
      console.error("Password reset error:", error)
      showMessage("Failed to send reset email. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault()

    if (otpCode.length !== 6) {
      showMessage("Please enter a valid 6-digit code", "error")
      return
    }

    setLoading(true)
    setMessage("")

    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email: email.trim(),
        token: otpCode,
        type: "recovery",
      })

      if (error) {
        console.error("OTP verification error:", error)
        if (error.message.includes("expired")) {
          showMessage("Reset code has expired. Please request a new one.", "error")
        } else if (error.message.includes("invalid")) {
          showMessage("Invalid reset code. Please check and try again.", "error")
        } else {
          showMessage(error.message || "Verification failed. Please try again.", "error")
        }
      } else if (data.session) {
        setStep("password")
        showMessage("Code verified! Now set your new password.", "success")
      }
    } catch (error: any) {
      console.error("OTP verification error:", error)
      showMessage("Verification failed. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newPassword) {
      showMessage("Please enter a new password", "error")
      return
    }

    if (newPassword.length < 6) {
      showMessage("Password must be at least 6 characters long", "error")
      return
    }

    if (newPassword !== confirmPassword) {
      showMessage("Passwords do not match", "error")
      return
    }

    setLoading(true)
    setMessage("")

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      })

      if (error) {
        console.error("Password update error:", error)
        showMessage(error.message || "Failed to update password", "error")
      } else {
        showMessage("Password updated successfully! You can now sign in.", "success")
        setTimeout(() => {
          onBack()
        }, 2000)
      }
    } catch (error: any) {
      console.error("Password update error:", error)
      showMessage("Failed to update password. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  const resendResetCode = async () => {
    setLoading(true)
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      })

      if (error) {
        showMessage(error.message || "Failed to resend code", "error")
      } else {
        showMessage("Reset code sent again! Check your email.", "success")
      }
    } catch (error: any) {
      showMessage("Failed to resend code. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="relative z-10 w-full max-w-md bg-black/40 backdrop-blur-sm border-purple-500/30 p-8">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-purple-300 hover:text-purple-200 p-0 h-auto"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>

        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🔐</div>
          <h1 className="text-3xl font-bold text-white mb-2">Reset Password</h1>
          <p className="text-purple-200">
            {step === "email" && "Enter your email to receive a reset code"}
            {step === "otp" && "Enter the 6-digit code from your email"}
            {step === "password" && "Create your new password"}
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-2">
            <div className={`w-3 h-3 rounded-full ${step === "email" ? "bg-purple-500" : "bg-purple-500/30"}`} />
            <div
              className={`w-3 h-3 rounded-full ${step === "otp" ? "bg-purple-500" : step === "password" ? "bg-purple-500" : "bg-purple-500/30"}`}
            />
            <div className={`w-3 h-3 rounded-full ${step === "password" ? "bg-purple-500" : "bg-purple-500/30"}`} />
          </div>
        </div>

        {/* Step 1: Email */}
        {step === "email" && (
          <form onSubmit={handleSendResetEmail} className="space-y-4">
            <div>
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3"
            >
              {loading ? "Sending..." : "Send Reset Code"}
            </Button>
          </form>
        )}

        {/* Step 2: OTP Verification */}
        {step === "otp" && (
          <form onSubmit={handleVerifyOTP} className="space-y-4">
            <div>
              <Input
                type="text"
                placeholder="Enter 6-digit code"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300 text-center text-2xl tracking-widest"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading || otpCode.length !== 6}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3"
            >
              {loading ? "Verifying..." : "Verify Code"}
            </Button>

            <Button
              onClick={resendResetCode}
              variant="outline"
              className="w-full border-purple-500 text-purple-300 hover:bg-purple-600 hover:text-white bg-transparent"
            >
              Resend Code
            </Button>
          </form>
        )}

        {/* Step 3: New Password */}
        {step === "password" && (
          <form onSubmit={handleUpdatePassword} className="space-y-4">
            <div>
              <Input
                type="password"
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
              />
            </div>

            <div>
              <Input
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-black/30 border-purple-500/30 text-white placeholder-purple-300"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3"
            >
              {loading ? "Updating..." : "Update Password"}
            </Button>
          </form>
        )}

        {/* Message Display */}
        {message && (
          <div
            className={`mt-4 p-3 rounded-lg text-sm border ${
              messageType === "error"
                ? "bg-red-500/20 text-red-300 border-red-500/30"
                : messageType === "success"
                  ? "bg-green-500/20 text-green-300 border-green-500/30"
                  : "bg-blue-500/20 text-blue-300 border-blue-500/30"
            }`}
          >
            {message}
          </div>
        )}

        <p className="text-xs text-purple-400 opacity-80 text-center mt-4">
          Check your spam folder if you don't see the email within a few minutes
        </p>
      </Card>
    </div>
  )
}
