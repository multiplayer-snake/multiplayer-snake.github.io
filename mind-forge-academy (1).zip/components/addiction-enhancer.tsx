"use client"

import { useGame } from "@/contexts/game-context"
import { useAudio } from "@/contexts/audio-context"
import { useEffect, useState } from "react"

export default function AddictionEnhancer() {
  const { state, dispatch } = useGame()
  const { playSound } = useAudio()
  const [showUrgency, setShowUrgency] = useState(false)
  const [showSocial, setShowSocial] = useState(false)

  // Addiction Psychology Triggers
  useEffect(() => {
    // FOMO Timer - Creates urgency
    const urgencyTimer = setInterval(() => {
      if (Math.random() < 0.2) {
        setShowUrgency(true)
        setTimeout(() => setShowUrgency(false), 5000)
      }
    }, 30000)

    // Social Proof - Shows others' activity
    const socialTimer = setInterval(() => {
      if (Math.random() < 0.3) {
        setShowSocial(true)
        setTimeout(() => setShowSocial(false), 4000)
      }
    }, 20000)

    // Dopamine Decay - Keeps players engaged
    const dopamineDecay = setInterval(() => {
      if (state.dopamineLevel > 0) {
        dispatch({ type: "INCREASE_DOPAMINE", payload: -1 })
      }
    }, 5000)

    return () => {
      clearInterval(urgencyTimer)
      clearInterval(socialTimer)
      clearInterval(dopamineDecay)
    }
  }, [state.dopamineLevel, dispatch])

  // Achievement Cascade Trigger
  useEffect(() => {
    if (state.streak > 0 && state.streak % 3 === 0) {
      playSound("achievement", 1.5)

      // Trigger cascade of smaller achievements
      setTimeout(() => playSound("bonus", 1.2), 200)
      setTimeout(() => playSound("correct", 1.0), 400)
    }
  }, [state.streak, playSound])

  return (
    <>
      {/* FOMO Urgency Messages */}
      {showUrgency && (
        <div className="fixed top-1/4 left-1/2 transform -translate-x-1/2 z-50 animate-bounce">
          <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-6 py-4 rounded-lg shadow-2xl border-2 border-yellow-400">
            <div className="text-center">
              <div className="text-lg font-bold">⏰ LIMITED TIME!</div>
              <div className="text-sm">Double XP expires in {Math.floor(Math.random() * 10) + 5} minutes!</div>
              <div className="text-xs opacity-80 mt-1">Don't let others get ahead!</div>
            </div>
          </div>
        </div>
      )}

      {/* Social Proof Messages */}
      {showSocial && (
        <div className="fixed bottom-32 left-4 z-40 animate-slide-in-left">
          <div className="bg-green-600/90 backdrop-blur-sm text-white p-3 rounded-lg text-sm max-w-xs">
            <div className="font-semibold">🎉 Sarah just achieved a 15-streak!</div>
            <div className="text-xs opacity-80">You're only {15 - state.streak} away from beating her!</div>
          </div>
        </div>
      )}

      {/* Dopamine Level Indicator */}
      <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-30">
        <div className="w-3 h-40 bg-gray-800 rounded-full overflow-hidden border border-purple-500">
          <div
            className="w-full bg-gradient-to-t from-red-500 via-yellow-500 to-green-500 transition-all duration-1000 rounded-full"
            style={{ height: `${state.dopamineLevel}%` }}
          ></div>
        </div>
        <div className="text-white text-xs mt-2 text-center transform -rotate-90 origin-center">Dopamine</div>
      </div>

      {/* Competitive Pressure */}
      {state.competitiveRank <= 100 && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-40">
          <div className="bg-yellow-600/90 backdrop-blur-sm text-black px-4 py-2 rounded-full font-bold text-sm animate-pulse">
            🏆 TOP 100 PLAYER! Rank #{state.competitiveRank}
          </div>
        </div>
      )}
    </>
  )
}
