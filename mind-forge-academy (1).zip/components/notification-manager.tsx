"use client"

import { useAuth } from "@/hooks/use-auth"
import { useGame } from "@/contexts/game-context"
import { useEffect, useRef, useState } from "react"

interface NotificationTrigger {
  type: string
  title: string
  body: string
  icon?: string
  badge?: string
  tag?: string
  requiresPermission?: boolean
  delay?: number
}

export default function NotificationManager() {
  const { user, userProfile } = useAuth()
  const { state } = useGame()
  const lastNotificationRef = useRef<number>(0)
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>("default")
  const [serviceWorkerReady, setServiceWorkerReady] = useState(false)

  // Check notification permission on mount
  useEffect(() => {
    if ("Notification" in window) {
      setNotificationPermission(Notification.permission)
    }
  }, [])

  // Register service worker for push notifications
  useEffect(() => {
    if ("serviceWorker" in navigator && "PushManager" in window) {
      navigator.serviceWorker
        .register("/sw.js")
        .then((registration) => {
          console.log("SW registered:", registration)
          setServiceWorkerReady(true)
        })
        .catch((error) => {
          console.log("SW registration failed:", error)
        })
    }
  }, [])

  // Request notification permission when user signs in
  useEffect(() => {
    if (user && notificationPermission === "default") {
      requestNotificationPermission()
    }
  }, [user, notificationPermission])

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      try {
        const permission = await Notification.requestPermission()
        setNotificationPermission(permission)

        if (permission === "granted") {
          showWelcomeNotification()
        }
      } catch (error) {
        console.error("Error requesting notification permission:", error)
      }
    }
  }

  const showWelcomeNotification = () => {
    if (userProfile?.first_name) {
      showNotification({
        type: "welcome",
        title: `Welcome back, ${userProfile.first_name}! 🧠`,
        body: "Ready to expand your mind? Your personalized learning journey awaits!",
        icon: "/icon-192x192.png",
        tag: "welcome",
      })
    }
  }

  // Notification triggers based on game state and user behavior
  useEffect(() => {
    if (!user || !userProfile || notificationPermission !== "granted") return

    const now = Date.now()
    const timeSinceLastNotification = now - lastNotificationRef.current

    // Prevent notification spam (minimum 30 seconds between notifications)
    if (timeSinceLastNotification < 30000) return

    // Check user's notification preferences
    const prefs = userProfile.notification_preferences || {}

    const triggers: NotificationTrigger[] = [
      // Achievement notifications
      {
        type: "achievement",
        title: `🏆 Amazing work, ${userProfile.first_name}!`,
        body: `You've unlocked a new achievement! Your brain is getting stronger.`,
        icon: "/icon-192x192.png",
        tag: "achievement",
      },

      // Streak milestone notifications
      {
        type: "streak_milestone",
        title: `🔥 Incredible streak, ${userProfile.first_name}!`,
        body: `${state.streak} correct answers in a row! You're absolutely on fire!`,
        icon: "/icon-192x192.png",
        tag: "streak",
      },

      // Genius mode activation
      {
        type: "genius_mode",
        title: `🧠 GENIUS MODE ACTIVATED, ${userProfile.first_name}!`,
        body: "Your neural pathways are supercharged! Keep that momentum going!",
        icon: "/icon-192x192.png",
        tag: "genius",
      },

      // Level up notifications
      {
        type: "level_up",
        title: `⭐ Level Up, ${userProfile.first_name}!`,
        body: `Congratulations! You've reached level ${state.level}! What an achievement!`,
        icon: "/icon-192x192.png",
        tag: "level",
      },
    ]

    // Check for achievement notifications
    if (prefs.achievements && state.achievements.length > (userProfile.achievements?.length || 0)) {
      showNotification(triggers[0])
    }

    // Check for streak milestones
    if (prefs.achievements && state.streak > 0 && state.streak % 5 === 0 && state.streak > 5) {
      showNotification(triggers[1])
    }

    // Check for genius mode
    if (prefs.achievements && state.geniusMode && state.geniusModeTimer === 10) {
      showNotification(triggers[2])
    }
  }, [state.achievements, state.streak, state.geniusMode, state.level, user, userProfile, notificationPermission])

  // Inactivity and comeback notifications
  useEffect(() => {
    if (!user || !userProfile || notificationPermission !== "granted") return

    const prefs = userProfile.notification_preferences || {}
    const firstName = userProfile.first_name || "genius"

    const scheduleInactivityNotifications = () => {
      // 1 hour inactivity
      setTimeout(
        () => {
          if (prefs.dailyReminders) {
            showNotification({
              type: "comeback_1h",
              title: `🎯 ${firstName}, your brain misses you!`,
              body: "Come back and continue your amazing learning streak!",
              icon: "/icon-192x192.png",
              tag: "comeback",
            })
          }
        },
        60 * 60 * 1000,
      ) // 1 hour

      // 6 hours inactivity
      setTimeout(
        () => {
          if (prefs.streakWarnings) {
            showNotification({
              type: "streak_warning",
              title: `⚠️ ${firstName}, your streak is in danger!`,
              body: `Your ${userProfile.current_streak || 0}-day streak is about to break! Don't lose your amazing progress!`,
              icon: "/icon-192x192.png",
              tag: "streak_warning",
            })
          }
        },
        6 * 60 * 60 * 1000,
      ) // 6 hours

      // 24 hours inactivity
      setTimeout(
        () => {
          if (prefs.socialUpdates) {
            showNotification({
              type: "social_pressure",
              title: `👥 ${firstName}, your rivals are getting ahead!`,
              body: "Sarah just beat your high score! Time to reclaim your throne!",
              icon: "/icon-192x192.png",
              tag: "social",
            })
          }
        },
        24 * 60 * 60 * 1000,
      ) // 24 hours
    }

    scheduleInactivityNotifications()
  }, [user, userProfile, notificationPermission])

  // Daily study reminders
  useEffect(() => {
    if (!user || !userProfile || notificationPermission !== "granted") return

    const prefs = userProfile.notification_preferences || {}
    const firstName = userProfile.first_name || "genius"

    if (!prefs.dailyReminders) return

    const scheduleDailyReminders = () => {
      const now = new Date()
      const tomorrow = new Date(now)
      tomorrow.setDate(tomorrow.getDate() + 1)
      tomorrow.setHours(9, 0, 0, 0) // 9 AM next day

      const timeUntilReminder = tomorrow.getTime() - now.getTime()

      setTimeout(() => {
        showNotification({
          type: "daily_reminder",
          title: `🌅 Good morning, ${firstName}!`,
          body: "Ready to expand your brilliant mind? Your daily challenge awaits!",
          icon: "/icon-192x192.png",
          tag: "daily",
        })

        // Schedule recurring daily reminders
        setInterval(
          () => {
            const reminderMessages = [
              `🧠 Time to feed your amazing brain, ${firstName}!`,
              `🎯 ${firstName}, your daily dose of knowledge is ready!`,
              `⚡ Quick study session, ${firstName}? Your streak depends on it!`,
              `🏆 Champions study daily, ${firstName}. Are you ready?`,
              `🔥 Keep your learning fire burning, ${firstName}!`,
            ]

            showNotification({
              type: "daily_reminder",
              title: "📚 Study Time!",
              body: reminderMessages[Math.floor(Math.random() * reminderMessages.length)],
              icon: "/icon-192x192.png",
              tag: "daily",
            })
          },
          24 * 60 * 60 * 1000,
        ) // Every 24 hours
      }, timeUntilReminder)
    }

    scheduleDailyReminders()
  }, [user, userProfile, notificationPermission])

  // Weekend challenge notifications
  useEffect(() => {
    if (!user || !userProfile || notificationPermission !== "granted") return

    const prefs = userProfile.notification_preferences || {}
    const firstName = userProfile.first_name || "genius"

    if (!prefs.challenges) return

    const scheduleWeekendChallenges = () => {
      const now = new Date()
      const daysUntilSaturday = (6 - now.getDay()) % 7
      const nextSaturday = new Date(now)
      nextSaturday.setDate(now.getDate() + daysUntilSaturday)
      nextSaturday.setHours(10, 0, 0, 0)

      const timeUntilWeekend = nextSaturday.getTime() - now.getTime()

      setTimeout(() => {
        showNotification({
          type: "weekend_challenge",
          title: `🎉 ${firstName}, Weekend Challenge Available!`,
          body: "Special weekend challenge with 5x XP bonus! Limited time only!",
          icon: "/icon-192x192.png",
          tag: "weekend",
        })
      }, timeUntilWeekend)
    }

    scheduleWeekendChallenges()
  }, [user, userProfile, notificationPermission])

  const showNotification = (trigger: NotificationTrigger) => {
    if (notificationPermission !== "granted") return

    try {
      lastNotificationRef.current = Date.now()

      const notification = new Notification(trigger.title, {
        body: trigger.body,
        icon: trigger.icon || "/icon-192x192.png",
        badge: trigger.badge || "/badge-72x72.png",
        tag: trigger.tag,
        requireInteraction: false,
        silent: false,
      })

      notification.onclick = () => {
        window.focus()
        notification.close()
      }

      // Auto-close after 8 seconds
      setTimeout(() => {
        notification.close()
      }, 8000)
    } catch (error) {
      console.error("Error showing notification:", error)
    }
  }

  return null // This component doesn't render anything
}
